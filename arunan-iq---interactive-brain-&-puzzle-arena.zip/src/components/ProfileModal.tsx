import React, { useState, useEffect } from 'react';
import { UserProfile } from '../types/game';
import { getUserProfile, updateUserProfile } from '../utils/storage';
import { sound } from '../utils/audio';
import { User, X, Award, CheckCircle2, Zap, Flame, Trophy, ShieldCheck, Check } from 'lucide-react';

interface Props {
  isOpen: boolean;
  onClose: () => void;
}

export const ProfileModal: React.FC<Props> = ({ isOpen, onClose }) => {
  const [profile, setProfile] = useState<UserProfile>(getUserProfile());
  const [nameInput, setNameInput] = useState(profile.playerName);
  const [isEditing, setIsEditing] = useState(false);

  useEffect(() => {
    if (isOpen) {
      const p = getUserProfile();
      setProfile(p);
      setNameInput(p.playerName);
    }
  }, [isOpen]);

  if (!isOpen) return null;

  const handleSave = () => {
    if (!nameInput.trim()) return;
    const updated = updateUserProfile({ playerName: nameInput.trim() });
    setProfile(updated);
    setIsEditing(false);
    sound.playSuccess();
  };

  const allBadges = [
    { id: 'First Move', title: 'Initiate', desc: 'Complete your first logical puzzle' },
    { id: 'Flawless Deductor', title: 'Flawless Mind', desc: 'Solve a puzzle with 100% accuracy' },
    { id: 'Speed Demon', title: 'Speed Demon', desc: 'Solve any challenge in under 45 seconds' },
    { id: 'Gifted Mind (IQ 130+)', title: 'Gifted Mind', desc: 'Achieve an estimated IQ score of 130+' },
    { id: 'Genius Tier (IQ 145+)', title: 'Genius Tier', desc: 'Achieve an estimated IQ rating of 145+' },
    { id: 'Master Strategist (8k+)', title: 'Grandmaster', desc: 'Score over 8,000 points in a single run' },
    { id: 'Certified Evaluated', title: 'Evaluated', desc: 'Complete the standardized 8-step IQ Assessment' },
  ];

  const winRate =
    profile.gamesPlayed > 0
      ? Math.round((profile.gamesWon / profile.gamesPlayed) * 100)
      : 0;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-sm animate-fade-in">
      <div className="w-full max-w-lg bg-slate-900 border border-slate-800 rounded-3xl p-6 space-y-6 shadow-2xl overflow-hidden">
        <div className="flex items-center justify-between border-b border-slate-800 pb-4">
          <div className="flex items-center gap-3">
            <div className="p-2 rounded-xl bg-cyan-500/10 border border-cyan-500/20 text-cyan-400">
              <User className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-lg font-bold text-white tracking-tight">Player Profile & Stats</h2>
              <p className="text-xs text-slate-400">Persisted locally in your browser</p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="p-2 rounded-xl text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Name section */}
        <div className="p-4 rounded-2xl bg-slate-950 border border-slate-800 flex items-center justify-between">
          <div>
            <span className="text-[11px] font-mono text-slate-500 block uppercase">Player Alias</span>
            {isEditing ? (
              <div className="flex items-center gap-2 mt-1">
                <input
                  type="text"
                  value={nameInput}
                  onChange={(e) => setNameInput(e.target.value)}
                  maxLength={20}
                  className="bg-slate-900 border border-cyan-500 px-2 py-1 rounded text-white text-sm font-semibold focus:outline-none"
                  autoFocus
                />
                <button
                  type="button"
                  onClick={handleSave}
                  className="p-1.5 rounded bg-cyan-500 text-slate-950 hover:bg-cyan-400"
                >
                  <Check className="w-4 h-4" />
                </button>
              </div>
            ) : (
              <span className="text-base font-bold text-slate-100">{profile.playerName}</span>
            )}
          </div>
          {!isEditing && (
            <button
              type="button"
              onClick={() => setIsEditing(true)}
              className="text-xs text-cyan-400 hover:text-cyan-300 font-medium"
            >
              Rename
            </button>
          )}
        </div>

        {/* Stats Grid */}
        <div className="grid grid-cols-3 gap-3">
          <div className="p-3 rounded-2xl bg-slate-950 border border-slate-800 text-center">
            <span className="text-[10px] text-slate-500 font-mono block">Highest IQ</span>
            <span className="text-2xl font-black text-cyan-400 font-mono tabular-nums">
              {profile.highestIQ}
            </span>
          </div>

          <div className="p-3 rounded-2xl bg-slate-950 border border-slate-800 text-center">
            <span className="text-[10px] text-slate-500 font-mono block">Solved</span>
            <span className="text-2xl font-black text-emerald-400 font-mono tabular-nums">
              {profile.gamesWon}
            </span>
          </div>

          <div className="p-3 rounded-2xl bg-slate-950 border border-slate-800 text-center">
            <span className="text-[10px] text-slate-500 font-mono block">Win Rate</span>
            <span className="text-2xl font-black text-slate-200 font-mono tabular-nums">
              {winRate}%
            </span>
          </div>
        </div>

        {/* Badges */}
        <div className="space-y-3">
          <span className="text-xs font-semibold text-slate-300 block">Unlocked Cognitive Badges:</span>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 max-h-48 overflow-y-auto pr-1">
            {allBadges.map((badge) => {
              const isUnlocked = profile.unlockedBadges.includes(badge.id);
              return (
                <div
                  key={badge.id}
                  className={`p-2.5 rounded-xl border flex items-start gap-2.5 transition-all ${
                    isUnlocked
                      ? 'bg-slate-950/80 border-cyan-500/30 text-slate-200'
                      : 'bg-slate-950/30 border-slate-800/40 text-slate-600 opacity-50'
                  }`}
                >
                  <Award
                    className={`w-4 h-4 shrink-0 mt-0.5 ${
                      isUnlocked ? 'text-amber-400' : 'text-slate-600'
                    }`}
                  />
                  <div>
                    <span className="text-xs font-bold block">{badge.title}</span>
                    <span className="text-[10px] text-slate-500 block leading-tight">
                      {badge.desc}
                    </span>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </div>
    </div>
  );
};
