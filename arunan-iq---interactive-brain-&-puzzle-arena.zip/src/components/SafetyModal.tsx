import React from 'react';
import { AppLanguage } from '../types/i18n';
import { sound } from '../utils/audio';
import {
  ShieldCheck,
  Lock,
  WifiOff,
  Smile,
  X,
  CheckCircle2,
  Sparkles,
  Award,
  EyeOff,
  Smartphone,
  Globe2,
} from 'lucide-react';

interface Props {
  isOpen: boolean;
  onClose: () => void;
  currentLang: AppLanguage;
}

export const SafetyModal: React.FC<Props> = ({ isOpen, onClose, currentLang }) => {
  if (!isOpen) return null;

  const isTa = currentLang === 'ta';
  const isFr = currentLang === 'fr';
  const isEs = currentLang === 'es';
  const isHi = currentLang === 'hi';

  const safetyPillars = [
    {
      icon: <EyeOff className="w-6 h-6 text-emerald-400" />,
      title: isTa
        ? 'விளம்பரங்கள் இல்லை (100% Ad-Free)'
        : isFr
        ? '100% Sans Publicité'
        : isEs
        ? '100% Sin Publicidad'
        : isHi
        ? '100% विज्ञापन-मुक्त'
        : '100% Ad-Free & Distraction-Free',
      description: isTa
        ? 'எந்தவித பாப்-அப் அல்லது மூன்றாம் தரப்பு விளம்பரங்களும் இல்லை. குழந்தைகள் கவனச்சிதறல் இன்றி பாதுகாப்பாக கற்கலாம்.'
        : isFr
        ? 'Aucune publicité intempestive ni traqueur commercial. Sécurisé pour les enfants et les écoles.'
        : isEs
        ? 'Sin anuncios emergentes ni rastreadores. Seguro para niños, escuelas y familias.'
        : isHi
        ? 'कोई पॉप-अप या विज्ञापन नहीं। बच्चे और परिवार बिना किसी रुकावट के खेल सकते हैं।'
        : 'Zero pop-ups, zero third-party banners, and zero commercials. Safe for young learners and classrooms.',
      badge: 'Certified Clean',
      color: 'border-emerald-500/30 bg-emerald-500/5',
    },
    {
      icon: <Lock className="w-6 h-6 text-cyan-400" />,
      title: isTa
        ? 'முழு தனிஉரிமை & லோக்கல் ஸ்டோரேஜ்'
        : isFr
        ? 'Confidentialité Totale (Stockage Local)'
        : isEs
        ? 'Privacidad Total (Almacenamiento Local)'
        : isHi
        ? 'पूर्ण गोपनीयता (लोकल स्टोरेज)'
        : 'Complete Privacy & Local Storage Only',
      description: isTa
        ? 'உங்கள் மதிப்பெண்கள், புதிர்கள் மற்றும் ஆட்ட முன்னேற்றம் உங்கள் சாதனத்திலேயே (LocalStorage) பத்திரமாக இருக்கும். தனிப்பட்ட தகவல்கள் சேகரிக்கப்படுவதில்லை.'
        : isFr
        ? 'Vos scores et progressions sont enregistrés uniquement sur votre appareil. Aucune donnée personnelle transmise.'
        : isEs
        ? 'Sus puntajes y avances se guardan únicamente en su navegador. No recopilamos datos personales.'
        : isHi
        ? 'आपका स्कोर और प्रोग्रेस केवल आपके डिवाइस में सुरक्षित रहता है। कोई व्यक्तिगत डेटा नहीं लिया जाता।'
        : 'All game progress, scores, and settings reside strictly on your own device. No personal data collection or tracking.',
      badge: 'Zero Telemetry',
      color: 'border-cyan-500/30 bg-cyan-500/5',
    },
    {
      icon: <Smile className="w-6 h-6 text-amber-400" />,
      title: isTa
        ? 'குழந்தைகள் & குடும்பத்தினருக்கு ஏற்றது'
        : isFr
        ? 'Adapté aux Enfants & Familles'
        : isEs
        ? 'Apto para Niños y Familias'
        : isHi
        ? 'बच्चों और परिवारों के लिए सुरक्षित'
        : 'Child-Safe & Family-Friendly (COPPA Aligned)',
      description: isTa
        ? 'வயது 4 முதல் பெரியவர்கள் வரை அனைவரும் விளையாடக்கூடிய ஆரோக்கியமான அறிவுசார் புதிர்கள், வண்ணமயமான விலங்குகள் மற்றும் ஊக்குவிக்கும் குரல் வாசிப்பு.'
        : isFr
        ? 'Énigmes positives adaptées dès 4 ans avec narration vocale bienveillante et logique saine.'
        : isEs
        ? 'Rompecabezas sanos y educativos para edades de 4 años en adelante, con lectura en voz alta.'
        : isHi
        ? '4 वर्ष और उससे अधिक आयु के बच्चों के लिए सकारात्मक सोच और तार्किक विकास पहेलियाँ।'
        : 'Wholesome logic riddles designed for ages 4+. Encourages constructive cognitive growth without violence.',
      badge: 'Ages 4+',
      color: 'border-amber-500/30 bg-amber-500/5',
    },
    {
      icon: <WifiOff className="w-6 h-6 text-purple-400" />,
      title: isTa
        ? '100% ஆஃப்லைனில் செயல்படும்'
        : isFr
        ? 'Fonctionne 100% Hors Ligne'
        : isEs
        ? 'Funciona 100% Sin Internet'
        : isHi
        ? '100% ऑफलाइन कार्यक्षमता'
        : '100% Offline Operation',
      description: isTa
        ? 'இணைய இணைப்பு இல்லாவிட்டாலும் தடையின்றி இயங்கும். வெளி உலக தொடர்பின்றி பாதுகாப்பான தனி சூழலில் செயல்படுகிறது.'
        : isFr
        ? 'Fonctionne sans connexion Internet après le premier chargement. Aucune dépendance externe.'
        : isEs
        ? 'No requiere conexión a Internet una vez cargado. Seguro contra interrupciones de red.'
        : isHi
        ? 'इंटरनेट के बिना भी सभी पहेलियाँ और स्तर सुचारू रूप से चलते हैं।'
        : 'Runs seamlessly without an internet connection once loaded. Immune to unexpected network shifts.',
      badge: 'Offline Safe',
      color: 'border-purple-500/30 bg-purple-500/5',
    },
    {
      icon: <Award className="w-6 h-6 text-red-400" />,
      title: isTa
        ? 'உறுதிசெய்யப்பட்ட படைப்பு: Arunan S'
        : isFr
        ? 'Vérifié par le Développeur Arunan S'
        : isEs
        ? 'Verificado por el Creador Arunan S'
        : isHi
        ? 'निर्माता अरूनन एस द्वारा सत्यापित'
        : 'Verified & Maintained by Arunan S',
      description: isTa
        ? 'சுயாதீனமான மென்பொருள் பொறியாளர் Arunan S அவர்களின் மேற்பார்வையில் நம்பகத்தன்மையுடன் உருவாக்கப்பட்டு பராமரிக்கப்படுகிறது.'
        : isFr
        ? 'Développé et maintenu par Arunan S avec les plus hauts standards de transparence et de sécurité.'
        : isEs
        ? 'Desarrollado y respaldado de forma independiente por Arunan S para garantizar máxima fiabilidad.'
        : isHi
        ? 'स्वतंत्र डेवलपर अरूनन एस द्वारा उच्च मानकों के साथ तैयार और प्रबंधित।'
        : 'Engineered and maintained with transparent software architecture by Arunan S for dependable learning.',
      badge: 'Author Verified',
      color: 'border-red-500/30 bg-red-500/5',
    },
    {
      icon: <ShieldCheck className="w-6 h-6 text-emerald-400" />,
      title: isTa
        ? 'பாதுகாப்பான HTTPS & PWA கட்டமைப்பு'
        : isFr
        ? 'Architecture Sécurisée HTTPS & PWA'
        : isEs
        ? 'Arquitectura Segura HTTPS y PWA'
        : isHi
        ? 'सुरक्षित HTTPS एवं PWA तकनीक'
        : 'Encrypted HTTPS & Progressive Web App',
      description: isTa
        ? 'குறியாக்கப்பட்ட TLS/HTTPS பாதுகாப்புடன் நவீன இணையத் தரநிலைகளுக்கு உட்பட்டு இயங்குகிறது.'
        : isFr
        ? 'Connexion chiffrée SSL/TLS et conteneurisation autonome pour une sécurité maximale.'
        : isEs
        ? 'Conexión cifrada de extremo a extremo conforme a los estándares web modernos.'
        : isHi
        ? 'आधुनिक वेब सुरक्षा मानकों और एन्क्रिप्टेड प्रोटोकॉल पर आधारित।'
        : 'Delivered via modern encrypted HTTPS standards with sandboxed client execution and responsive isolation.',
      badge: 'TLS Protected',
      color: 'border-emerald-500/30 bg-emerald-500/5',
    },
  ];

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-slate-950/85 backdrop-blur-md animate-fade-in overflow-y-auto">
      <div className="w-full max-w-2xl bg-slate-900 border-2 border-emerald-500/40 rounded-3xl p-6 sm:p-8 shadow-2xl relative space-y-6 my-auto">
        {/* Close Button */}
        <button
          type="button"
          onClick={() => {
            sound.playClick(440);
            onClose();
          }}
          className="absolute top-5 right-5 p-2 rounded-xl bg-slate-800 text-slate-400 hover:text-white transition-colors cursor-pointer"
          aria-label="Close"
        >
          <X className="w-4 h-4" />
        </button>

        {/* Modal Header */}
        <div className="flex items-center gap-3.5 pr-8">
          <div className="w-14 h-14 rounded-2xl bg-gradient-to-br from-emerald-500/20 to-teal-500/10 border-2 border-emerald-500/50 flex items-center justify-center text-emerald-400 shrink-0 shadow-lg">
            <ShieldCheck className="w-7 h-7" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className="px-2.5 py-0.5 rounded-full bg-emerald-500/20 border border-emerald-500/40 text-[10px] font-mono text-emerald-300 font-bold uppercase tracking-wider">
                100% Safe Website & App
              </span>
              <span className="text-xs text-slate-400 font-mono hidden sm:inline">
                Made by Arunan S
              </span>
            </div>
            <h2 className="text-xl sm:text-2xl font-black text-white tracking-tight mt-0.5">
              {isTa ? 'பாதுகாப்பு & தனிஉரிமை உத்தரவாதம்' : 'Safety & Privacy Guarantee'}
            </h2>
          </div>
        </div>

        {/* Trust Banner */}
        <div className="p-4 rounded-2xl bg-gradient-to-r from-emerald-950/40 to-slate-950 border border-emerald-500/30 flex items-center justify-between gap-3 text-xs">
          <div className="flex items-center gap-2.5 text-emerald-300">
            <Sparkles className="w-4 h-4 text-emerald-400 shrink-0" />
            <span className="font-semibold">
              {isTa
                ? 'அருணன் IQ இணையதளம் 100% விளம்பரமற்றது, பாதுகாப்பானது மற்றும் தரவுகளைச் சேமிக்காதது.'
                : 'Arunan IQ is certified 100% ad-free, child-friendly, and does not harvest personal data.'}
            </span>
          </div>
          <span className="shrink-0 px-2 py-0.5 rounded bg-emerald-500/20 text-emerald-300 font-mono font-bold text-[11px]">
            PASSED ✓
          </span>
        </div>

        {/* Safety Pillars Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5 max-h-[50vh] overflow-y-auto pr-1">
          {safetyPillars.map((p, idx) => (
            <div
              key={idx}
              className={`p-4 rounded-2xl border ${p.color} space-y-2 flex flex-col justify-between`}
            >
              <div className="space-y-1.5">
                <div className="flex items-center justify-between">
                  <div className="p-1.5 rounded-xl bg-slate-900 border border-slate-800">
                    {p.icon}
                  </div>
                  <span className="text-[10px] font-mono font-bold px-2 py-0.5 rounded-full bg-slate-900/90 text-slate-300 border border-slate-700">
                    {p.badge}
                  </span>
                </div>
                <h3 className="text-sm font-bold text-white leading-snug">{p.title}</h3>
                <p className="text-xs text-slate-300 leading-relaxed">{p.description}</p>
              </div>
            </div>
          ))}
        </div>

        {/* Footer info & CTA */}
        <div className="pt-3 border-t border-slate-800/80 flex flex-wrap items-center justify-between gap-3 text-xs">
          <div className="flex items-center gap-2 text-slate-400">
            <CheckCircle2 className="w-4 h-4 text-emerald-400" />
            <span>COPPA & GDPR Privacy Aligned · Safe for Schools</span>
          </div>

          <button
            type="button"
            onClick={() => {
              sound.playSuccess();
              onClose();
            }}
            className="px-5 py-2 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-bold text-xs transition-all cursor-pointer shadow-md"
          >
            {isTa ? 'புரிந்தது, ஆட்டத்தைத் தொடர்க' : 'Got it, Continue Playing'}
          </button>
        </div>
      </div>
    </div>
  );
};
