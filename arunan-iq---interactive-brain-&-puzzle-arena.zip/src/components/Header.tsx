import React, { useState } from 'react';
import { GameMode } from '../types/game';
import { AppLanguage, LANGUAGES } from '../types/i18n';
import { t } from '../utils/i18n';
import { sound } from '../utils/audio';
import { AppLogo } from './AppLogo';
import {
  Trophy,
  Volume2,
  VolumeX,
  BarChart3,
  Globe,
  ChevronDown,
  Sparkles,
  Smartphone,
  Globe2,
  ShieldCheck,
} from 'lucide-react';

interface Props {
  currentMode: GameMode;
  onSelectMode: (mode: GameMode) => void;
  onOpenLeaderboard: () => void;
  onOpenProfile: () => void;
  onOpenIntro: () => void;
  isMuted: boolean;
  onToggleMute: () => void;
  currentLang: AppLanguage;
  onSelectLanguage: (lang: AppLanguage) => void;
  viewMode?: 'app' | 'website';
  onToggleViewMode?: (mode: 'app' | 'website') => void;
  onOpenInstall?: () => void;
  onOpenLanguageModal?: () => void;
  onOpenSafetyModal?: () => void;
}

export const Header: React.FC<Props> = ({
  currentMode,
  onSelectMode,
  onOpenLeaderboard,
  onOpenProfile,
  onOpenIntro,
  isMuted,
  onToggleMute,
  currentLang,
  onSelectLanguage,
  viewMode = 'app',
  onToggleViewMode,
  onOpenInstall,
  onOpenLanguageModal,
  onOpenSafetyModal,
}) => {
  const [isLangMenuOpen, setIsLangMenuOpen] = useState(false);
  const activeLangObj = LANGUAGES.find((l) => l.code === currentLang) || LANGUAGES[0];

  return (
    <header className="w-full border-b border-slate-800 bg-slate-950/95 backdrop-blur-md sticky top-0 z-40 shadow-lg">
      <div className="max-w-7xl mx-auto px-4 sm:px-6">
        {/* Tier 1: Top Brand & Utility Controls */}
        <div className="h-14 sm:h-16 flex items-center justify-between gap-2 sm:gap-4 border-b border-slate-800/60 overflow-visible relative">
          {/* Brand Wordmark & Official App Logo & Creator */}
          <div className="flex items-center gap-1.5 sm:gap-3 shrink-0">
            {/* Compact logo on mobile, full logo on tablet/desktop */}
            <AppLogo variant="compact" size="sm" className="sm:hidden" />
            <AppLogo variant="full" size="sm" className="hidden sm:inline-flex" />
            
            {/* Creator Badge - clearly visible on all screen sizes */}
            <span className="inline-flex items-center gap-1 sm:gap-1.5 px-2 sm:px-2.5 py-0.5 sm:py-1 rounded-full bg-red-950/70 border border-red-500/40 text-[10px] sm:text-[11px] font-mono text-red-300 font-semibold shadow-sm shrink-0">
              <span className="w-1.5 h-1.5 rounded-full bg-red-400 animate-pulse" />
              <span className="hidden sm:inline">
                {currentLang === 'ta' ? 'ஆக்கியவர்: Arunan S' : 'Made by Arunan S'}
              </span>
              <span className="sm:hidden font-bold">Arunan S</span>
            </span>

            {/* Safe Website Trust Badge */}
            {onOpenSafetyModal && (
              <button
                type="button"
                onClick={() => {
                  sound.playClick(440);
                  onOpenSafetyModal();
                }}
                className="inline-flex items-center gap-1 sm:gap-1.5 px-2 sm:px-2.5 py-0.5 sm:py-1 rounded-full bg-emerald-950/70 border border-emerald-500/40 text-[10px] sm:text-[11px] font-mono text-emerald-300 font-semibold shadow-sm shrink-0 cursor-pointer hover:bg-emerald-900/60 transition-colors"
                title="100% Safe Website & Child-Friendly Certified"
              >
                <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
                <span className="hidden md:inline">100% Safe</span>
                <span className="md:hidden">Safe</span>
              </button>
            )}
          </div>

          {/* Center App vs Website Switcher */}
          {onToggleViewMode && (
            <div className="flex items-center p-0.5 sm:p-1 rounded-xl bg-slate-900 border border-slate-800 shrink-0 text-xs">
              <button
                type="button"
                onClick={() => {
                  sound.playClick(500);
                  onToggleViewMode('app');
                }}
                className={`px-2 sm:px-3 py-1 rounded-lg text-xs font-bold transition-all cursor-pointer ${
                  viewMode === 'app'
                    ? 'bg-amber-400 text-slate-950 shadow-sm'
                    : 'text-slate-400 hover:text-white'
                }`}
                title="Interactive App Mode"
              >
                🎮 <span className="hidden md:inline">{currentLang === 'ta' ? 'செயலி' : 'App'}</span>
              </button>
              <button
                type="button"
                onClick={() => {
                  sound.playClick(520);
                  onToggleViewMode('website');
                }}
                className={`px-2 sm:px-3 py-1 rounded-lg text-xs font-bold transition-all cursor-pointer ${
                  viewMode === 'website'
                    ? 'bg-red-600 text-white shadow-sm'
                    : 'text-slate-400 hover:text-white'
                }`}
                title="Website Showcase & Information"
              >
                🌐 <span className="hidden md:inline">{currentLang === 'ta' ? 'இணையதளம்' : 'Website'}</span>
              </button>
            </div>
          )}

          {/* Quick Actions (Install, Language, Sound, Profile, Intro, Leaderboard) */}
          <div className="flex items-center gap-1 sm:gap-2 shrink-0">
            {/* Install PWA App Button */}
            {onOpenInstall && (
              <button
                type="button"
                onClick={() => {
                  sound.playClick(520);
                  onOpenInstall();
                }}
                className="flex items-center gap-1.5 p-2 sm:px-3 sm:py-1.5 rounded-xl bg-emerald-500/15 hover:bg-emerald-500/25 text-emerald-300 border border-emerald-500/35 text-xs font-bold transition-all cursor-pointer shadow-sm"
                title="Install Progressive Web App on Phone or PC"
              >
                <Smartphone className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
                <span className="hidden lg:inline">{currentLang === 'ta' ? 'நிறுவுக' : 'Install App'}</span>
              </button>
            )}

            {/* Multilingual Selector Dropdown */}
            <div className="relative">
              <button
                type="button"
                onClick={() => {
                  sound.playClick(440);
                  setIsLangMenuOpen((prev) => !prev);
                }}
                className="flex items-center gap-1 px-2.5 sm:px-3 py-1.5 rounded-xl bg-slate-900 hover:bg-slate-800 border border-slate-700 text-xs sm:text-sm font-semibold text-slate-100 transition-all cursor-pointer shadow-sm hover:border-amber-400/50"
                title="Select Language / மொழியை மாற்றவும்"
                aria-label="Select Language"
                aria-expanded={isLangMenuOpen}
              >
                <span className="text-base select-none">{activeLangObj.flag}</span>
                <span className="font-sans font-bold text-xs">{activeLangObj.nativeName}</span>
                <ChevronDown className={`w-3.5 h-3.5 text-slate-400 transition-transform ${isLangMenuOpen ? 'rotate-180 text-amber-400' : ''}`} />
              </button>

              {isLangMenuOpen && (
                <>
                  {/* Backdrop to close anywhere on tap outside */}
                  <div
                    className="fixed inset-0 z-40 bg-slate-950/20 backdrop-blur-[1px]"
                    onClick={() => setIsLangMenuOpen(false)}
                  />
                  <div className="absolute right-0 top-full mt-2 w-56 sm:w-64 rounded-2xl bg-slate-900 border-2 border-amber-500/30 shadow-2xl p-2 z-50 animate-fade-in divide-y divide-slate-800/80">
                    <div className="px-2 py-1 text-[11px] font-mono uppercase text-amber-400 tracking-wider font-bold flex items-center justify-between">
                      <span>{currentLang === 'ta' ? 'மொழிகள் (5 Languages)' : 'Languages (5)'}</span>
                      <span className="text-[10px] text-slate-400">100% Offline</span>
                    </div>

                    <div className="pt-1.5 pb-1 space-y-1">
                      {LANGUAGES.map((langItem) => {
                        const isSelected = currentLang === langItem.code;
                        return (
                          <button
                            key={langItem.code}
                            type="button"
                            onClick={() => {
                              sound.playSuccess();
                              onSelectLanguage(langItem.code);
                              setIsLangMenuOpen(false);
                            }}
                            className={`w-full flex items-center justify-between px-3 py-2 rounded-xl text-xs sm:text-sm font-medium transition-all text-left cursor-pointer ${
                              isSelected
                                ? 'bg-amber-400 text-slate-950 font-bold shadow-md'
                                : 'text-slate-300 hover:bg-slate-800 hover:text-white'
                            }`}
                          >
                            <div className="flex items-center gap-2.5">
                              <span className="text-xl select-none">{langItem.flag}</span>
                              <div className="flex flex-col">
                                <span className="font-bold leading-tight">{langItem.nativeName}</span>
                                <span className={`text-[10px] ${isSelected ? 'text-slate-900 font-semibold' : 'text-slate-400'}`}>
                                  {langItem.name}
                                </span>
                              </div>
                            </div>
                            {isSelected && (
                              <span className="text-xs font-mono font-black px-1.5 py-0.5 rounded-full bg-slate-950 text-amber-300 shadow-sm">
                                ✓
                              </span>
                            )}
                          </button>
                        );
                      })}
                    </div>

                    {onOpenLanguageModal && (
                      <div className="pt-1.5">
                        <button
                          type="button"
                          onClick={() => {
                            sound.playClick(440);
                            setIsLangMenuOpen(false);
                            onOpenLanguageModal();
                          }}
                          className="w-full py-1.5 px-2 text-center text-xs font-semibold text-amber-400 hover:text-amber-300 hover:bg-amber-500/10 rounded-lg transition-colors cursor-pointer flex items-center justify-center gap-1.5"
                        >
                          <Globe className="w-3.5 h-3.5" />
                          <span>{currentLang === 'ta' ? 'விரிவான மொழிப் பலகை...' : 'More Language Info...'}</span>
                        </button>
                      </div>
                    )}
                  </div>
                </>
              )}
            </div>

            {/* Mute Button */}
            <button
              type="button"
              onClick={() => {
                sound.playClick(440);
                onToggleMute();
              }}
              aria-label={isMuted ? 'Unmute sound' : 'Mute sound'}
              title={isMuted ? 'Unmute sound' : 'Mute sound'}
              className="p-1.5 sm:p-2 rounded-xl text-slate-400 hover:text-slate-100 hover:bg-slate-900 border border-transparent hover:border-slate-800 transition-colors"
            >
              {isMuted ? <VolumeX className="w-4 h-4 text-rose-400" /> : <Volume2 className="w-4 h-4" />}
            </button>

            {/* Profile / Stats Button */}
            <button
              type="button"
              onClick={() => {
                sound.playClick(600);
                onOpenProfile();
              }}
              aria-label={t('stats', currentLang)}
              title={t('stats', currentLang)}
              className="p-1.5 sm:p-2 rounded-xl text-slate-400 hover:text-slate-100 hover:bg-slate-900 border border-transparent hover:border-slate-800 transition-colors hidden sm:flex items-center"
            >
              <BarChart3 className="w-4 h-4" />
            </button>

            {/* App Intro Button */}
            <button
              type="button"
              onClick={() => {
                sound.playClick(500);
                onOpenIntro();
              }}
              className="flex items-center gap-1 px-2.5 sm:px-3.5 py-1.5 text-xs sm:text-sm font-bold rounded-xl bg-amber-500/15 text-amber-300 border border-amber-500/35 hover:bg-amber-500/25 transition-all cursor-pointer whitespace-nowrap shadow-sm hover:shadow"
              title={currentLang === 'ta' ? 'அருணன் IQ அறிமுகம் & சுற்றுலா' : 'Arunan IQ Intro & Overview'}
            >
              <Sparkles className="w-3.5 h-3.5 text-amber-400" />
              <span className="hidden sm:inline">
                {currentLang === 'ta'
                  ? 'அறிமுகம்'
                  : currentLang === 'fr'
                  ? 'Intro'
                  : currentLang === 'es'
                  ? 'Intro'
                  : currentLang === 'hi'
                  ? 'परिचय'
                  : 'App Intro'}
              </span>
            </button>

            {/* Leaderboard Button */}
            <button
              type="button"
              onClick={() => {
                sound.playSuccess();
                onOpenLeaderboard();
              }}
              className="flex items-center gap-1 p-1.5 sm:px-3 sm:py-1.5 text-xs sm:text-sm font-semibold rounded-xl bg-amber-500/10 text-amber-400 border border-amber-500/30 hover:bg-amber-500/20 transition-all cursor-pointer whitespace-nowrap"
              title={t('leaderboard', currentLang)}
            >
              <Trophy className="w-4 h-4 text-amber-400" />
              <span className="hidden xl:inline">{t('leaderboard', currentLang)}</span>
            </button>
          </div>
        </div>

        {/* Tier 2: Big Mode Navigation Bar */}
        <nav className="py-2.5 sm:py-3 flex items-center gap-2 sm:gap-2.5 overflow-x-auto no-scrollbar scroll-smooth">
          {/* 1. Child IQ Mode */}
          <button
            type="button"
            onClick={() => {
              sound.playClick(540);
              onSelectMode('child');
            }}
            className={`px-4 sm:px-5 py-2 sm:py-2.5 text-sm sm:text-base font-bold rounded-xl transition-all whitespace-nowrap flex items-center gap-2 cursor-pointer shadow-sm ${
              currentMode === 'child'
                ? 'bg-amber-400 text-slate-950 font-black shadow-md ring-2 ring-amber-300'
                : 'text-amber-400 bg-amber-500/10 hover:bg-amber-500/20 border border-amber-500/25'
            }`}
          >
            <span className="text-base sm:text-lg">⭐</span>
            <span>{t('modeChild', currentLang).replace('⭐ ', '')}</span>
          </button>

          {/* 2. Flagship: Detective Arunan (Big & Prominent!) */}
          <button
            type="button"
            onClick={() => {
              sound.playClick(530);
              onSelectMode('detective');
            }}
            className={`px-4 sm:px-5 py-2 sm:py-2.5 text-sm sm:text-base font-bold rounded-xl transition-all whitespace-nowrap flex items-center gap-2 cursor-pointer shadow-sm ${
              currentMode === 'detective'
                ? 'bg-gradient-to-r from-red-600 via-rose-600 to-amber-600 text-white font-black shadow-lg shadow-red-600/30 ring-2 ring-red-400'
                : 'text-red-400 bg-red-950/40 hover:bg-red-900/40 border border-red-500/40 hover:text-red-300'
            }`}
          >
            <span className="text-base sm:text-lg">🕵️‍♂️</span>
            <span>{t('modeDetective', currentLang).replace('🕵️‍♂️ ', '')}</span>
          </button>

          {/* 3. Easy & Correct English Learning Mode */}
          <button
            type="button"
            onClick={() => {
              sound.playClick(510);
              onSelectMode('english');
            }}
            className={`px-4 sm:px-5 py-2 sm:py-2.5 text-sm sm:text-base font-bold rounded-xl transition-all whitespace-nowrap flex items-center gap-2 cursor-pointer shadow-sm ${
              currentMode === 'english'
                ? 'bg-gradient-to-r from-indigo-500 via-purple-500 to-indigo-600 text-white font-black shadow-lg shadow-indigo-500/30 ring-2 ring-indigo-400'
                : 'text-indigo-400 bg-indigo-950/40 hover:bg-indigo-900/40 border border-indigo-500/40 hover:text-indigo-300'
            }`}
          >
            <span className="text-base sm:text-lg">🔤</span>
            <span>{t('modeEnglish', currentLang).replace('🔤 ', '')}</span>
          </button>

          {/* 4. Grid Deduction */}
          <button
            type="button"
            onClick={() => {
              sound.playClick(500);
              onSelectMode('grid');
            }}
            className={`px-4 sm:px-5 py-2 sm:py-2.5 text-sm sm:text-base font-medium rounded-xl transition-all whitespace-nowrap flex items-center gap-2 cursor-pointer ${
              currentMode === 'grid'
                ? 'bg-cyan-500 text-slate-950 font-bold shadow-md ring-2 ring-cyan-300'
                : 'text-slate-300 bg-slate-900 hover:bg-slate-800 border border-slate-800 hover:text-white'
            }`}
          >
            <span className="text-base sm:text-lg">🧩</span>
            <span>{t('modeGrid', currentLang)}</span>
          </button>

          {/* 4. Pattern Matrix */}
          <button
            type="button"
            onClick={() => {
              sound.playClick(500);
              onSelectMode('pattern');
            }}
            className={`px-4 sm:px-5 py-2 sm:py-2.5 text-sm sm:text-base font-medium rounded-xl transition-all whitespace-nowrap flex items-center gap-2 cursor-pointer ${
              currentMode === 'pattern'
                ? 'bg-cyan-500 text-slate-950 font-bold shadow-md ring-2 ring-cyan-300'
                : 'text-slate-300 bg-slate-900 hover:bg-slate-800 border border-slate-800 hover:text-white'
            }`}
          >
            <span className="text-base sm:text-lg">🔷</span>
            <span>{t('modePattern', currentLang)}</span>
          </button>

          {/* 5. Sequences */}
          <button
            type="button"
            onClick={() => {
              sound.playClick(500);
              onSelectMode('sequence');
            }}
            className={`px-4 sm:px-5 py-2 sm:py-2.5 text-sm sm:text-base font-medium rounded-xl transition-all whitespace-nowrap flex items-center gap-2 cursor-pointer ${
              currentMode === 'sequence'
                ? 'bg-cyan-500 text-slate-950 font-bold shadow-md ring-2 ring-cyan-300'
                : 'text-slate-300 bg-slate-900 hover:bg-slate-800 border border-slate-800 hover:text-white'
            }`}
          >
            <span className="text-base sm:text-lg">🔢</span>
            <span>{t('modeSequence', currentLang)}</span>
          </button>

          {/* 6. IQ Assessment */}
          <button
            type="button"
            onClick={() => {
              sound.playClick(500);
              onSelectMode('assessment');
            }}
            className={`px-4 sm:px-5 py-2 sm:py-2.5 text-sm sm:text-base font-medium rounded-xl transition-all whitespace-nowrap flex items-center gap-2 cursor-pointer ${
              currentMode === 'assessment'
                ? 'bg-emerald-500 text-slate-950 font-bold shadow-md ring-2 ring-emerald-300'
                : 'text-emerald-400 bg-emerald-950/30 hover:bg-emerald-900/40 border border-emerald-500/30'
            }`}
          >
            <span className="text-base sm:text-lg">🧠</span>
            <span>{t('modeAssessment', currentLang)}</span>
          </button>
        </nav>
      </div>
    </header>
  );
};

