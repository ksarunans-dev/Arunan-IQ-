import React from 'react';

interface AppLogoProps {
  variant?: 'full' | 'compact' | 'icon';
  size?: 'sm' | 'md' | 'lg' | 'xl';
  className?: string;
  showSubtitle?: boolean;
}

export const AppLogo: React.FC<AppLogoProps> = ({
  variant = 'full',
  size = 'md',
  className = '',
  showSubtitle = false,
}) => {
  // Height sizing
  const heightClass = {
    sm: 'h-8',
    md: 'h-10',
    lg: 'h-14',
    xl: 'h-20',
  }[size];

  if (variant === 'icon') {
    return (
      <div
        className={`relative inline-flex items-center justify-center rounded-xl bg-[#c41622] text-white shadow-md select-none shrink-0 overflow-hidden ${
          size === 'sm'
            ? 'w-8 h-8 rounded-lg'
            : size === 'md'
            ? 'w-10 h-10 rounded-xl'
            : size === 'lg'
            ? 'w-14 h-14 rounded-2xl'
            : 'w-20 h-20 rounded-3xl'
        } ${className}`}
        aria-label="Arunan IQ Logo"
      >
        {/* White circle medallion with red AI */}
        <div
          className={`rounded-full bg-white flex items-center justify-center font-serif font-bold shadow-sm ${
            size === 'sm'
              ? 'w-6 h-6 text-xs'
              : size === 'md'
              ? 'w-7 h-7 text-sm'
              : size === 'lg'
              ? 'w-10 h-10 text-xl'
              : 'w-14 h-14 text-2xl'
          } text-[#c41622]`}
        >
          AI
        </div>
      </div>
    );
  }

  if (variant === 'compact') {
    return (
      <div
        className={`inline-flex items-center gap-2.5 px-3 py-1.5 rounded-2xl bg-[#c41622] text-white shadow-lg border border-red-500/30 select-none ${className}`}
      >
        {/* Brain Icon Outline */}
        <svg
          className="w-5 h-5 text-white/95 shrink-0"
          viewBox="0 0 64 64"
          fill="none"
          stroke="currentColor"
          strokeWidth="2.5"
          strokeLinecap="round"
          strokeLinejoin="round"
        >
          <path d="M24,46 C22,46 20,44 19,42 C15,42 12,39 12,35 C9,34 7,31 7,27 C7,23 10,19 13,18 C13,14 16,11 20,11 C23,11 25,12 26,14 C27,12 30,11 32,11 C32,15 31,19 30,22 C31,26 30,31 28,34 C30,37 29,41 27,43 C26,45 25,46 24,46 Z" />
          <path d="M13,18 C16,20 19,19 20,22 C21,25 18,27 16,27" />
          <path d="M12,35 C15,34 17,36 19,35 C21,33 20,30 23,29" />
          <path d="M40,46 C42,46 44,44 45,42 C49,42 52,39 52,35 C55,34 57,31 57,27 C57,23 54,19 51,18 C51,14 48,11 44,11 C41,11 39,12 38,14 C37,12 34,11 32,11 C32,15 33,19 34,22 C33,26 34,31 36,34 C34,37 35,41 37,43 C38,45 39,46 40,46 Z" />
          <path d="M51,18 C48,20 45,19 44,22 C43,25 46,27 48,27" />
          <path d="M52,35 C49,34 47,36 45,35 C43,33 44,30 41,29" />
          <line x1="32" y1="11" x2="32" y2="45" strokeDasharray="2 2" />
        </svg>

        {/* White Medallion with red AI */}
        <div className="w-6 h-6 rounded-full bg-white flex items-center justify-center font-serif font-bold text-xs text-[#c41622] shadow-sm shrink-0">
          AI
        </div>

        {/* Text */}
        <span className="font-extrabold tracking-widest text-xs uppercase font-sans text-white">
          ARUNAN IQ
        </span>
      </div>
    );
  }

  // Full lockup matching uploaded image
  return (
    <div
      className={`inline-flex items-center gap-2 sm:gap-3 px-3 sm:px-4 py-1.5 sm:py-2 rounded-2xl bg-[#c41622] text-white shadow-xl border border-red-500/40 select-none shrink-0 ${className}`}
    >
      {/* 1. Brain line-art icon */}
      <svg
        className="w-5 h-5 sm:w-6 sm:h-6 text-white/90 shrink-0"
        viewBox="0 0 64 64"
        fill="none"
        stroke="currentColor"
        strokeWidth="2.4"
        strokeLinecap="round"
        strokeLinejoin="round"
      >
        <path d="M24,46 C22,46 20,44 19,42 C15,42 12,39 12,35 C9,34 7,31 7,27 C7,23 10,19 13,18 C13,14 16,11 20,11 C23,11 25,12 26,14 C27,12 30,11 32,11 C32,15 31,19 30,22 C31,26 30,31 28,34 C30,37 29,41 27,43 C26,45 25,46 24,46 Z" />
        <path d="M13,18 C16,20 19,19 20,22 C21,25 18,27 16,27" />
        <path d="M12,35 C15,34 17,36 19,35 C21,33 20,30 23,29" />
        <path d="M40,46 C42,46 44,44 45,42 C49,42 52,39 52,35 C55,34 57,31 57,27 C57,23 54,19 51,18 C51,14 48,11 44,11 C41,11 39,12 38,14 C37,12 34,11 32,11 C32,15 33,19 34,22 C33,26 34,31 36,34 C34,37 35,41 37,43 C38,45 39,46 40,46 Z" />
        <path d="M51,18 C48,20 45,19 44,22 C43,25 46,27 48,27" />
        <path d="M52,35 C49,34 47,36 45,35 C43,33 44,30 41,29" />
        <line x1="32" y1="11" x2="32" y2="45" strokeDasharray="2 2" />
      </svg>

      {/* 2. White Circle with Red Serif "AI" */}
      <div className="w-7 h-7 sm:w-8 sm:h-8 rounded-full bg-white flex items-center justify-center font-serif font-black text-xs sm:text-sm text-[#c41622] shadow-sm shrink-0">
        AI
      </div>

      {/* 3. ARUNAN IQ Wordmark */}
      <div className="flex flex-col">
        <span className="font-extrabold tracking-wider sm:tracking-widest text-sm sm:text-base font-sans text-white leading-tight">
          ARUNAN IQ
        </span>
        {showSubtitle && (
          <span className="text-[10px] tracking-wider text-red-200/90 font-mono -mt-0.5">
            LOGIC & COGNITIVE ARENA
          </span>
        )}
      </div>
    </div>
  );
};
