import React, { useState, useEffect } from 'react';
import { DetectiveCase, Difficulty } from '../types/game';
import { AppLanguage, LANGUAGES } from '../types/i18n';
import { t, getSpeechLangCode } from '../utils/i18n';
import { DETECTIVE_MEHUL_CASES, getLocalizedCase } from '../data/detectiveMehulCases';
import { sound } from '../utils/audio';
import { triggerConfetti } from '../utils/confetti';
import { saveScoreToLeaderboard } from '../utils/storage';
import { loadDetectiveSession, saveDetectiveSession, clearSession } from '../utils/gameSessionStorage';
import {
  Search,
  CheckCircle2,
  XCircle,
  HelpCircle,
  Sparkles,
  Clock,
  RotateCcw,
  ChevronRight,
  Volume2,
  VolumeX,
  Languages,
  ShieldAlert,
  Award,
  Zap,
  Eye,
  FileText,
  BookmarkCheck,
} from 'lucide-react';

interface Props {
  currentLang: AppLanguage;
  onSelectLanguage: (lang: AppLanguage) => void;
  onWin: (stats: {
    mode: 'detective';
    difficulty: Difficulty;
    score: number;
    iqEstimate: number;
    timeSeconds: number;
    accuracy: number;
    title: string;
  }) => void;
}

export const DetectiveMehulGame: React.FC<Props> = ({
  currentLang,
  onSelectLanguage,
  onWin,
}) => {
  const initialSaved = React.useMemo(() => loadDetectiveSession(), []);

  const [caseIndex, setCaseIndex] = useState(() => initialSaved?.caseIndex ?? 0);
  const [selectedSuspectId, setSelectedSuspectId] = useState<number | null>(
    () => initialSaved?.selectedSuspectId ?? null
  );
  const [isAnswered, setIsAnswered] = useState(() => initialSaved?.isAnswered ?? false);
  const [isCorrect, setIsCorrect] = useState<boolean | null>(() => initialSaved?.isCorrect ?? null);
  const [revealedClues, setRevealedClues] = useState<number[]>(
    () => initialSaved?.revealedClues ?? []
  );
  const [timeElapsed, setTimeElapsed] = useState(() => initialSaved?.timeElapsed ?? 0);
  const [solvedCount, setSolvedCount] = useState(() => initialSaved?.solvedCount ?? 0);
  const [isSpeaking, setIsSpeaking] = useState(false);
  const [isResumedBanner, setIsResumedBanner] = useState(
    () =>
      Boolean(
        initialSaved &&
          (initialSaved.caseIndex > 0 ||
            initialSaved.solvedCount > 0 ||
            (initialSaved.revealedClues && initialSaved.revealedClues.length > 0))
      )
  );

  const isFirstRenderRef = React.useRef(true);
  const prevCaseIndexRef = React.useRef(caseIndex);

  const currentCase: DetectiveCase =
    DETECTIVE_MEHUL_CASES[caseIndex % DETECTIVE_MEHUL_CASES.length];

  const loc = getLocalizedCase(currentCase, currentLang);

  const isTa = currentLang === 'ta';
  const isFr = currentLang === 'fr';
  const isEs = currentLang === 'es';
  const isHi = currentLang === 'hi';

  // Initialize case when caseIndex changes (not on first restored render)
  useEffect(() => {
    if (isFirstRenderRef.current) {
      isFirstRenderRef.current = false;
      return;
    }
    if (prevCaseIndexRef.current !== caseIndex) {
      prevCaseIndexRef.current = caseIndex;
      setSelectedSuspectId(null);
      setIsAnswered(false);
      setIsCorrect(null);
      setRevealedClues([]);
      setTimeElapsed(0);
    }
    if ('speechSynthesis' in window) {
      window.speechSynthesis.cancel();
    }
    setIsSpeaking(false);
  }, [caseIndex, currentLang]);

  // Save session on any update & when user leaves app
  useEffect(() => {
    saveDetectiveSession({
      caseIndex,
      solvedCount,
      revealedClues,
      selectedSuspectId,
      timeElapsed,
      isAnswered,
      isCorrect,
      lastUpdated: Date.now(),
    });
  }, [caseIndex, solvedCount, revealedClues, selectedSuspectId, timeElapsed, isAnswered, isCorrect]);

  useEffect(() => {
    const handleVis = () => {
      saveDetectiveSession({
        caseIndex,
        solvedCount,
        revealedClues,
        selectedSuspectId,
        timeElapsed,
        isAnswered,
        isCorrect,
        lastUpdated: Date.now(),
      });
    };
    document.addEventListener('visibilitychange', handleVis);
    window.addEventListener('beforeunload', handleVis);
    return () => {
      document.removeEventListener('visibilitychange', handleVis);
      window.removeEventListener('beforeunload', handleVis);
    };
  }, [caseIndex, solvedCount, revealedClues, selectedSuspectId, timeElapsed, isAnswered, isCorrect]);

  // Timer: Pause when user leaves app or case is answered
  useEffect(() => {
    if (isAnswered) return;
    const interval = setInterval(() => {
      if (document.hidden) return; // Freeze timer while outside app!
      setTimeElapsed((prev) => prev + 1);
    }, 1000);
    return () => clearInterval(interval);
  }, [isAnswered]);

  const cycleLanguage = () => {
    sound.playClick(480);
    const order: AppLanguage[] = ['ta', 'en', 'fr', 'es', 'hi'];
    const curIdx = order.indexOf(currentLang);
    const nextLang = order[(curIdx + 1) % order.length];
    onSelectLanguage(nextLang);
    if ('speechSynthesis' in window) {
      window.speechSynthesis.cancel();
      setIsSpeaking(false);
    }
  };

  const handleSpeech = () => {
    if (!('speechSynthesis' in window)) return;
    if (isSpeaking) {
      window.speechSynthesis.cancel();
      setIsSpeaking(false);
      return;
    }

    const textToRead = `${loc.title}. ${loc.synopsis} ${loc.question}`;

    const utterance = new SpeechSynthesisUtterance(textToRead);
    utterance.lang = getSpeechLangCode(currentLang);
    utterance.rate = 0.95;
    utterance.onend = () => setIsSpeaking(false);
    utterance.onerror = () => setIsSpeaking(false);
    setIsSpeaking(true);
    window.speechSynthesis.speak(utterance);
  };

  const handleSelectSuspect = (id: number) => {
    if (isAnswered) return;
    sound.playClick(500);
    setSelectedSuspectId(id);
  };

  const handleToggleClue = (idx: number) => {
    sound.playClick(440);
    setRevealedClues((prev) =>
      prev.includes(idx) ? prev.filter((i) => i !== idx) : [...prev, idx]
    );
  };

  const handleSubmitDeduction = () => {
    if (selectedSuspectId === null || isAnswered) return;

    const correct = selectedSuspectId === currentCase.correctSuspectId;
    setIsAnswered(true);
    setIsCorrect(correct);

    if (correct) {
      sound.playFanfare();
      triggerConfetti();
      setSolvedCount((prev) => prev + 1);

      const baseScore =
        currentCase.difficulty === 'easy'
          ? 2500
          : currentCase.difficulty === 'medium'
          ? 4000
          : 6000;
      const timeBonus = Math.max(0, 90 - timeElapsed) * 15;
      const score = baseScore + timeBonus;
      const iqEstimate = Math.min(155, 125 + solvedCount * 5 + (timeElapsed < 45 ? 8 : 2));

      saveScoreToLeaderboard({
        playerName:
          currentLang === 'ta'
            ? 'துப்பறியும் அருணன் மாணவர்'
            : currentLang === 'fr'
            ? 'Détective Arunan Junior'
            : currentLang === 'es'
            ? 'Detective Arunan Cadete'
            : currentLang === 'hi'
            ? 'जासूस अरूनन छात्र'
            : 'Detective Arunan Cadre',
        mode: 'detective',
        difficulty: currentCase.difficulty,
        score,
        iqEstimate,
        timeSeconds: timeElapsed,
        accuracy: 100,
        notes: `Arunan Case #${currentCase.caseNumber}: ${loc.title}`,
      });

      onWin({
        mode: 'detective',
        difficulty: currentCase.difficulty,
        score,
        iqEstimate,
        timeSeconds: timeElapsed,
        accuracy: 100,
        title: loc.title,
      });
    } else {
      sound.playBuzzer();
    }
  };

  const handleNextCase = () => {
    sound.playClick(520);
    setCaseIndex((prev) => (prev + 1) % DETECTIVE_MEHUL_CASES.length);
  };

  const formatTime = (secs: number) => {
    const m = Math.floor(secs / 60);
    const s = secs % 60;
    return `${m.toString().padStart(2, '0')}:${s.toString().padStart(2, '0')}`;
  };

  const activeLangObj = LANGUAGES.find((l) => l.code === currentLang) || LANGUAGES[0];

  return (
    <div className="max-w-5xl mx-auto space-y-7">
      {/* Case Continuity Notification */}
      {isResumedBanner && (
        <div className="flex items-center justify-between px-4 py-2.5 rounded-2xl bg-amber-500/10 border border-amber-500/20 text-xs text-amber-300">
          <div className="flex items-center gap-2">
            <BookmarkCheck className="w-4 h-4 text-amber-400 shrink-0" />
            <span>
              {isTa
                ? `முந்தைய வழக்கு தொடர்கிறது: வழக்கு #${currentCase.caseNumber} - ${loc.title}`
                : `Resumed previous investigation: Case #${currentCase.caseNumber} - ${loc.title}`}
            </span>
          </div>
          <button
            type="button"
            onClick={() => {
              clearSession('detective');
              setCaseIndex(0);
              setSolvedCount(0);
              setSelectedSuspectId(null);
              setRevealedClues([]);
              setIsAnswered(false);
              setIsCorrect(null);
              setTimeElapsed(0);
              setIsResumedBanner(false);
            }}
            className="text-[11px] underline text-slate-400 hover:text-amber-200 cursor-pointer transition-colors"
          >
            {isTa ? 'முதல் வழக்கிலிருந்து தொடங்க' : 'Restart from Case #1'}
          </button>
        </div>
      )}

      {/* Top Banner - Detective Arunan Header with Language Toggle */}
      <div className="p-5 sm:p-6 rounded-3xl bg-gradient-to-r from-red-600/20 via-amber-500/15 to-slate-900 border-2 border-amber-500/30 flex flex-wrap items-center justify-between gap-5 shadow-2xl">
        <div className="flex items-center gap-4">
          <div className="w-16 h-16 rounded-2xl bg-gradient-to-br from-red-500/30 to-amber-500/30 border-2 border-amber-400/50 flex items-center justify-center text-4xl shadow-lg shrink-0">
            🕵️‍♂️
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className="text-xs sm:text-sm font-black text-amber-400 uppercase tracking-wider font-mono">
                {t('modeDetective', currentLang)}
              </span>
              <span className="text-slate-600">·</span>
              <span className="text-xs sm:text-sm text-slate-300 font-semibold capitalize">
                Case #{currentCase.caseNumber}
              </span>
            </div>
            <h2 className="text-2xl sm:text-3xl font-black text-white tracking-tight mt-0.5">
              {loc.title}
            </h2>
          </div>
        </div>

        {/* Action Controls: 5 Languages Switcher, Audio, Timer */}
        <div className="flex flex-wrap items-center gap-2 sm:gap-3">
          {/* Direct 5-Language Selector Pills */}
          <div className="flex items-center gap-1 p-1 rounded-2xl bg-slate-900/90 border border-slate-700/80 shadow-md">
            <span className="hidden xl:inline-flex items-center gap-1 pl-2 pr-1 text-[11px] font-mono text-slate-400 font-bold">
              <Languages className="w-3.5 h-3.5 text-amber-400" />
              <span>{isTa ? 'மொழி:' : 'Lang:'}</span>
            </span>
            {LANGUAGES.map((langItem) => {
              const isSelected = currentLang === langItem.code;
              return (
                <button
                  key={langItem.code}
                  type="button"
                  onClick={() => {
                    sound.playSuccess();
                    onSelectLanguage(langItem.code);
                  }}
                  className={`px-2.5 py-1.5 rounded-xl text-xs font-bold transition-all cursor-pointer flex items-center gap-1 ${
                    isSelected
                      ? 'bg-amber-400 text-slate-950 shadow-md scale-105'
                      : 'text-slate-300 hover:text-white hover:bg-slate-800'
                  }`}
                  title={`${langItem.name} (${langItem.nativeName})`}
                >
                  <span className="text-sm select-none">{langItem.flag}</span>
                  <span className="font-semibold text-[11px]">{langItem.nativeName}</span>
                </button>
              );
            })}
          </div>

          {/* Voice Read Aloud */}
          <button
            type="button"
            onClick={handleSpeech}
            className={`px-3 py-2 rounded-xl border flex items-center gap-1.5 text-xs sm:text-sm font-bold transition-all cursor-pointer ${
              isSpeaking
                ? 'bg-amber-400 text-slate-950 border-amber-300 animate-pulse shadow-md'
                : 'bg-slate-900 text-slate-200 border-slate-700 hover:text-white hover:bg-slate-800'
            }`}
            title={t('readAloud', currentLang)}
          >
            {isSpeaking ? <VolumeX className="w-4 h-4" /> : <Volume2 className="w-4 h-4 text-amber-400" />}
            <span className="hidden sm:inline">
              {isSpeaking ? t('stopVoice', currentLang) : t('readAloud', currentLang)}
            </span>
          </button>

          {/* Timer & Solved Counter */}
          <div className="flex items-center gap-3 bg-slate-950/90 px-3.5 py-2 rounded-xl border border-slate-700 text-xs sm:text-sm font-mono text-slate-200 shadow-inner">
            <div className="flex items-center gap-1.5 text-cyan-400 font-bold">
              <Clock className="w-4 h-4" />
              <span className="tabular-nums">{formatTime(timeElapsed)}</span>
            </div>
            <span className="text-slate-700">·</span>
            <div className="flex items-center gap-1.5 text-amber-400 font-bold">
              <Award className="w-4 h-4" />
              <span>
                {solvedCount} {t('solved', currentLang)}
              </span>
            </div>
          </div>
        </div>
      </div>

      {/* Main Case Dossier Container */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        {/* Left Column: Case Narrative Dossier & Suspects (8 cols) */}
        <div className="lg:col-span-8 space-y-6">
          {/* Case Narrative Dossier */}
          <div className="p-6 rounded-3xl bg-slate-900/60 border border-slate-800 space-y-4 shadow-xl">
            <div className="flex items-center justify-between border-b border-slate-800/80 pb-3">
              <div className="flex items-center gap-2 text-xs font-bold text-amber-400 font-mono uppercase tracking-wider">
                <FileText className="w-4 h-4" />
                <span>{t('crimeDossier', currentLang)}</span>
              </div>
              <span className="text-2xl select-none">{currentCase.sceneVisualEmoji}</span>
            </div>

            <p className="text-sm sm:text-base text-slate-200 leading-relaxed font-serif">
              "{loc.synopsis}"
            </p>

            {/* Crime Scene Details Checklist */}
            <div className="p-4 rounded-2xl bg-slate-950 border border-slate-800 space-y-2">
              <span className="text-xs font-bold text-slate-400 uppercase tracking-wider font-mono block">
                {currentLang === 'ta'
                  ? 'தடய அறிவியல் சான்றுகள்:'
                  : currentLang === 'fr'
                  ? 'Observations Médico-Légales :'
                  : currentLang === 'es'
                  ? 'Observaciones Forenses :'
                  : currentLang === 'hi'
                  ? 'अपराध स्थल के सुराग :'
                  : 'Forensic Crime Scene Observations:'}
              </span>
              <ul className="space-y-1.5 text-xs text-slate-300">
                {loc.crimeSceneDetails.map((detail, idx) => (
                  <li key={idx} className="flex items-start gap-2">
                    <span className="text-amber-400 font-bold">▶</span>
                    <span>{detail}</span>
                  </li>
                ))}
              </ul>
            </div>
          </div>

          {/* Suspect Statements Interrogation Area */}
          <div className="p-6 rounded-3xl bg-slate-900/60 border border-slate-800 space-y-4 shadow-xl">
            <div className="flex items-center justify-between border-b border-slate-800/80 pb-3">
              <div className="flex items-center gap-2 text-xs font-bold text-cyan-400 font-mono uppercase tracking-wider">
                <Eye className="w-4 h-4" />
                <span>{t('suspectStatements', currentLang)}</span>
              </div>
              <span className="text-xs text-slate-500 font-mono">
                {currentLang === 'ta'
                  ? 'ஒருவரைத் தேர்ந்தெடுக்கவும்'
                  : currentLang === 'fr'
                  ? 'Cliquer pour accuser'
                  : currentLang === 'es'
                  ? 'Toca para acusar'
                  : currentLang === 'hi'
                  ? 'आरोपी चुनें'
                  : 'Tap to accuse'}
              </span>
            </div>

            <div className="space-y-3">
              {loc.suspects.map((suspect) => {
                const isSelected = selectedSuspectId === suspect.id;
                let cardStyle =
                  'border-slate-800 bg-slate-950/70 hover:border-amber-400/50 hover:bg-slate-900';

                if (isSelected) {
                  cardStyle =
                    'border-amber-400 bg-amber-500/15 ring-2 ring-amber-400/50 shadow-[0_0_15px_rgba(251,191,36,0.25)]';
                }
                if (isAnswered) {
                  if (suspect.id === currentCase.correctSuspectId) {
                    cardStyle =
                      'border-emerald-500 bg-emerald-950/50 text-emerald-200 ring-2 ring-emerald-500';
                  } else if (isSelected && !isCorrect) {
                    cardStyle = 'border-rose-500 bg-rose-950/50 text-rose-200';
                  }
                }

                return (
                  <div
                    key={suspect.id}
                    onClick={() => handleSelectSuspect(suspect.id)}
                    className={`p-4 sm:p-5 rounded-2xl border-2 transition-all cursor-pointer flex items-start gap-4 select-none ${cardStyle}`}
                  >
                    <div className="w-14 h-14 rounded-2xl bg-slate-900 border border-slate-700 flex items-center justify-center text-4xl shrink-0 shadow-md">
                      {suspect.avatar}
                    </div>

                    <div className="flex-1 space-y-1.5">
                      <div className="flex items-center justify-between">
                        <span className="font-black text-base sm:text-lg text-white">
                          {suspect.name}
                        </span>
                        <span className="text-xs font-mono text-slate-400 bg-slate-900/80 px-2.5 py-0.5 rounded-lg border border-slate-800">
                          {suspect.role}
                        </span>
                      </div>
                      <p className="text-xs sm:text-sm text-slate-300 leading-relaxed font-serif italic">
                        "{suspect.statement}"
                      </p>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </div>

        {/* Right Column: Detective Question, Clues & Verdict (4 cols) */}
        <div className="lg:col-span-4 space-y-5">
          {/* Question & Accusation Button */}
          <div className="p-6 rounded-3xl bg-slate-900/60 border border-slate-800 space-y-4 shadow-xl">
            <div>
              <span className="text-xs sm:text-sm font-black text-amber-400 font-mono uppercase tracking-wider block">
                {currentLang === 'ta'
                  ? 'துப்பறியும் அருணனின் கேள்வி'
                  : currentLang === 'fr'
                  ? 'Le Défi du Détective Arunan'
                  : currentLang === 'es'
                  ? 'El Desafío del Detective Arunan'
                  : currentLang === 'hi'
                  ? 'जासूस अरूनन का सवाल'
                  : 'Detective Arunan’s Challenge'}
              </span>
              <h3 className="text-base sm:text-lg font-black text-white mt-1.5 leading-snug">
                {loc.question}
              </h3>
            </div>

            {!isAnswered ? (
              <button
                type="button"
                disabled={selectedSuspectId === null}
                onClick={handleSubmitDeduction}
                className="w-full py-4.5 px-5 rounded-2xl font-black text-base sm:text-lg bg-gradient-to-r from-red-600 via-amber-500 to-amber-400 hover:from-red-500 hover:to-amber-300 text-slate-950 transition-all flex items-center justify-center gap-2 cursor-pointer shadow-xl disabled:opacity-40 disabled:cursor-not-allowed"
              >
                <span>{t('arrestCulprit', currentLang)}</span>
                <ChevronRight className="w-5 h-5" />
              </button>
            ) : (
              <button
                type="button"
                onClick={handleNextCase}
                className="w-full py-4.5 px-5 rounded-2xl font-black text-base sm:text-lg bg-gradient-to-r from-emerald-400 to-emerald-500 hover:from-emerald-300 hover:to-emerald-400 text-slate-950 transition-all flex items-center justify-center gap-2 cursor-pointer shadow-xl"
              >
                <span>{t('nextCase', currentLang)}</span>
                <ChevronRight className="w-5 h-5" />
              </button>
            )}
          </div>

          {/* Interactive Magnifying Glass Clues */}
          <div className="p-5 rounded-3xl bg-slate-900/40 border border-slate-800 space-y-3">
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold text-cyan-400 flex items-center gap-1.5">
                <Search className="w-3.5 h-3.5" />
                <span>{t('detectiveClues', currentLang)}</span>
              </span>
              <span className="text-[11px] text-slate-500">
                {t('tapToInspect', currentLang)}
              </span>
            </div>

            <div className="space-y-2">
              {loc.clues.map((clue, idx) => {
                const isRevealed = revealedClues.includes(idx);
                return (
                  <button
                    key={idx}
                    type="button"
                    onClick={() => handleToggleClue(idx)}
                    className="w-full p-3 rounded-2xl bg-slate-950 border border-slate-800 hover:border-cyan-500/40 text-left transition-all cursor-pointer"
                  >
                    <div className="flex items-center justify-between text-xs">
                      <span className="font-bold text-slate-200 flex items-center gap-2">
                        <span>{clue.icon}</span>
                        <span>{clue.label}</span>
                      </span>
                      <span className="text-[10px] text-cyan-400 font-bold">
                        {isRevealed ? t('hideInspect', currentLang) : t('inspect', currentLang)}
                      </span>
                    </div>

                    {isRevealed && (
                      <p className="text-xs text-cyan-200/90 mt-2 pl-6 leading-relaxed border-t border-slate-800/80 pt-2 font-serif">
                        {clue.description}
                      </p>
                    )}
                  </button>
                );
              })}
            </div>
          </div>

          {/* Mehul's Signature Revelation (Shown after answering) */}
          {isAnswered && (
            <div
              className={`p-6 rounded-3xl border-2 space-y-3 transition-all ${
                isCorrect
                  ? 'bg-emerald-950/40 border-emerald-500/50 text-emerald-100 shadow-xl'
                  : 'bg-rose-950/40 border-rose-500/50 text-rose-100 shadow-xl'
              }`}
            >
              <div className="flex items-center gap-2 text-base font-black">
                {isCorrect ? (
                  <>
                    <CheckCircle2 className="w-6 h-6 text-emerald-400 shrink-0" />
                    <span className="text-emerald-300">
                      {t('caseSolved', currentLang)}
                    </span>
                  </>
                ) : (
                  <>
                    <XCircle className="w-6 h-6 text-rose-400 shrink-0" />
                    <span className="text-rose-300">
                      {t('caseFailed', currentLang)}
                    </span>
                  </>
                )}
              </div>

              <div className="space-y-2 text-xs sm:text-sm text-slate-200 leading-relaxed font-serif">
                <p>
                  <strong>{t('mehulVerdict', currentLang)}</strong> {loc.mehulVerdict}
                </p>
              </div>

              <div className="p-3 rounded-2xl bg-slate-950/80 border border-amber-500/30 text-xs font-bold text-amber-300 flex items-center gap-2">
                <span>🕵️‍♂️</span>
                <span className="italic">"{loc.catchphrase}"</span>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

