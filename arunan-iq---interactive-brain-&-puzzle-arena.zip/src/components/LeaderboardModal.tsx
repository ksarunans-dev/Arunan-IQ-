import React, { useState, useEffect, useMemo } from 'react';
import { Difficulty, GameMode, LeaderboardEntry } from '../types/game';
import {
  getLeaderboard,
  clearLeaderboard,
  exportLeaderboardJson,
  importLeaderboardJson,
  getUserProfile,
  updateUserProfile,
} from '../utils/storage';
import { sound } from '../utils/audio';
import { AppLanguage } from '../types/i18n';
import { t } from '../utils/i18n';
import {
  Trophy,
  X,
  Trash2,
  Download,
  Upload,
  User,
  Medal,
  Clock,
  Sparkles,
  Search,
  Filter,
  Check,
} from 'lucide-react';

interface Props {
  isOpen: boolean;
  onClose: () => void;
  highlightId?: string;
  currentLang?: AppLanguage;
}

export const LeaderboardModal: React.FC<Props> = ({
  isOpen,
  onClose,
  highlightId,
  currentLang = 'ta',
}) => {
  const [entries, setEntries] = useState<LeaderboardEntry[]>([]);
  const [modeFilter, setModeFilter] = useState<string>('all');
  const [diffFilter, setDiffFilter] = useState<string>('all');
  const [sortBy, setSortBy] = useState<'score' | 'iq' | 'time' | 'date'>('score');
  const [editingName, setEditingName] = useState(false);
  const [playerName, setPlayerName] = useState('Player 1');
  const [importStatus, setImportStatus] = useState<string | null>(null);

  const isTa = currentLang === 'ta';
  const isFr = currentLang === 'fr';
  const isEs = currentLang === 'es';
  const isHi = currentLang === 'hi';

  // Load leaderboard and user name
  const refreshData = () => {
    const data = getLeaderboard();
    setEntries(data);
    const profile = getUserProfile();
    setPlayerName(profile.playerName);
  };

  useEffect(() => {
    if (isOpen) {
      refreshData();
    }
  }, [isOpen]);

  const handleSaveName = () => {
    if (!playerName.trim()) return;
    updateUserProfile({ playerName: playerName.trim() });
    setEditingName(false);
    sound.playSuccess();
    refreshData();
  };

  const handleClear = () => {
    if (window.confirm('Reset local leaderboard scores to default benchmarks?')) {
      clearLeaderboard();
      sound.playClear();
      refreshData();
    }
  };

  const handleExport = () => {
    sound.playClick(500);
    const jsonStr = exportLeaderboardJson();
    const blob = new Blob([jsonStr], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `cogniq_scores_${new Date().toISOString().split('T')[0]}.json`;
    a.click();
    URL.revokeObjectURL(url);
  };

  const handleImportFile = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (event) => {
      const content = event.target?.result as string;
      const ok = importLeaderboardJson(content);
      if (ok) {
        sound.playSuccess();
        setImportStatus('Successfully imported records!');
        refreshData();
      } else {
        sound.playBuzzer();
        setImportStatus('Invalid JSON format');
      }
      setTimeout(() => setImportStatus(null), 3000);
    };
    reader.readAsText(file);
  };

  // Filter & Sort
  const filteredEntries = useMemo(() => {
    return entries
      .filter((e) => {
        if (modeFilter !== 'all' && e.mode !== modeFilter) return false;
        if (diffFilter !== 'all' && e.difficulty !== diffFilter) return false;
        return true;
      })
      .sort((a, b) => {
        if (sortBy === 'score') return b.score - a.score;
        if (sortBy === 'iq') return b.iqEstimate - a.iqEstimate;
        if (sortBy === 'time') return a.timeSeconds - b.timeSeconds;
        if (sortBy === 'date') return new Date(b.date).getTime() - new Date(a.date).getTime();
        return 0;
      });
  }, [entries, modeFilter, diffFilter, sortBy]);

  if (!isOpen) return null;

  const formatTime = (secs: number) => {
    const m = Math.floor(secs / 60);
    const s = secs % 60;
    return `${m.toString().padStart(2, '0')}:${s.toString().padStart(2, '0')}`;
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-sm animate-fade-in">
      <div className="w-full max-w-4xl max-h-[90vh] bg-slate-900 border border-slate-800 rounded-3xl shadow-2xl flex flex-col overflow-hidden">
        {/* Modal Header */}
        <div className="px-6 py-4 border-b border-slate-800 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="p-2 rounded-xl bg-amber-500/10 border border-amber-500/20 text-amber-400">
              <Trophy className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-lg font-bold text-white tracking-tight flex items-center gap-2">
                {t('appName', currentLang)} · {t('leaderboard', currentLang)}
              </h2>
              <p className="text-xs text-slate-400">
                {t('offlineNotice', currentLang)}
              </p>
            </div>
          </div>

          <button
            type="button"
            onClick={onClose}
            className="p-2 rounded-xl text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Player Profile Quick Setting */}
        <div className="px-6 py-3 bg-slate-950/60 border-b border-slate-800 flex flex-wrap items-center justify-between gap-3 text-xs">
          <div className="flex items-center gap-2">
            <User className="w-4 h-4 text-cyan-400" />
            <span className="text-slate-400">{t('player', currentLang)}:</span>
            {editingName ? (
              <div className="flex items-center gap-1.5">
                <input
                  type="text"
                  value={playerName}
                  onChange={(e) => setPlayerName(e.target.value)}
                  maxLength={24}
                  className="px-2 py-1 rounded bg-slate-900 border border-cyan-500 text-white font-semibold text-xs focus:outline-none"
                  autoFocus
                />
                <button
                  type="button"
                  onClick={handleSaveName}
                  className="p-1 rounded bg-cyan-500 text-slate-950 hover:bg-cyan-400"
                >
                  <Check className="w-3.5 h-3.5" />
                </button>
              </div>
            ) : (
              <button
                type="button"
                onClick={() => setEditingName(true)}
                className="font-bold text-slate-200 hover:text-cyan-400 underline underline-offset-2 transition-colors cursor-pointer"
              >
                {playerName}
              </button>
            )}
          </div>

          {/* Backup / Restore / Reset Controls */}
          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={handleExport}
              className="flex items-center gap-1 px-2.5 py-1 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 transition-colors cursor-pointer"
              title="Download local high scores as JSON file"
            >
              <Download className="w-3 h-3 text-cyan-400" />
              <span>{t('export', currentLang)}</span>
            </button>

            <label className="flex items-center gap-1 px-2.5 py-1 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 cursor-pointer transition-colors">
              <Upload className="w-3 h-3 text-emerald-400" />
              <span>{t('import', currentLang)}</span>
              <input type="file" accept=".json" onChange={handleImportFile} className="hidden" />
            </label>

            <button
              type="button"
              onClick={handleClear}
              className="flex items-center gap-1 px-2.5 py-1 rounded-lg bg-rose-950/30 hover:bg-rose-950/60 text-rose-400 border border-rose-800/40 transition-colors cursor-pointer"
              title="Reset scores to benchmarks"
            >
              <Trash2 className="w-3 h-3" />
              <span>{t('reset', currentLang)}</span>
            </button>
          </div>
        </div>

        {importStatus && (
          <div className="px-6 py-2 bg-emerald-950/40 text-emerald-300 text-xs border-b border-emerald-800/40">
            {importStatus}
          </div>
        )}

        {/* Filters & Sorting Segmented Controls */}
        <div className="p-4 px-6 bg-slate-900/40 border-b border-slate-800 flex flex-wrap items-center justify-between gap-3 text-xs">
          {/* Mode Filter */}
          <div className="flex items-center gap-1 p-1 bg-slate-950 rounded-xl border border-slate-800 overflow-x-auto">
            {[
              { id: 'all', label: t('allModes', currentLang) },
              { id: 'child', label: t('modeChild', currentLang) },
              { id: 'detective', label: t('modeDetective', currentLang) },
              { id: 'english', label: t('modeEnglish', currentLang) },
              { id: 'grid', label: t('modeGrid', currentLang) },
              { id: 'pattern', label: t('modePattern', currentLang) },
              { id: 'sequence', label: t('modeSequence', currentLang) },
              { id: 'assessment', label: t('modeAssessment', currentLang) },
            ].map((m) => (
              <button
                key={m.id}
                type="button"
                onClick={() => {
                  sound.playClick(460);
                  setModeFilter(m.id);
                }}
                className={`px-2.5 py-1 rounded-lg font-medium transition-all whitespace-nowrap ${
                  modeFilter === m.id
                    ? 'bg-amber-400 text-slate-950 font-bold shadow-sm'
                    : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                {m.label}
              </button>
            ))}
          </div>

          {/* Difficulty Filter */}
          <div className="flex items-center gap-1 p-1 bg-slate-950 rounded-xl border border-slate-800">
            {['all', 'easy', 'medium', 'hard', 'master'].map((d) => (
              <button
                key={d}
                type="button"
                onClick={() => {
                  sound.playClick(460);
                  setDiffFilter(d);
                }}
                className={`px-2.5 py-1 rounded-lg font-medium capitalize transition-all cursor-pointer ${
                  diffFilter === d
                    ? 'bg-slate-700 text-white font-bold shadow-sm'
                    : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                {d === 'all' ? t('allModes', currentLang) : t(d, currentLang)}
              </button>
            ))}
          </div>

          {/* Sort By */}
          <div className="flex items-center gap-1.5 text-slate-400">
            <span>{isTa ? 'வரிசைப்படுத்து:' : isFr ? 'Trier par :' : isEs ? 'Ordenar:' : isHi ? 'क्रमबद्ध:' : 'Sort:'}</span>
            <select
              value={sortBy}
              onChange={(e) => {
                sound.playClick(440);
                setSortBy(e.target.value as any);
              }}
              className="bg-slate-950 border border-slate-800 rounded-lg px-2.5 py-1 text-slate-200 focus:outline-none cursor-pointer"
            >
              <option value="score">{t('score', currentLang)} (Highest)</option>
              <option value="iq">IQ (Highest)</option>
              <option value="time">{t('time', currentLang)} (Fastest)</option>
              <option value="date">{isTa ? 'சமீபத்தியது' : isFr ? 'Plus Récent' : isEs ? 'Más Reciente' : isHi ? 'नवीनतम' : 'Most Recent'}</option>
            </select>
          </div>
        </div>

        {/* Table Content */}
        <div className="flex-1 overflow-y-auto p-4 sm:p-6 divide-y divide-slate-800/60">
          {filteredEntries.length === 0 ? (
            <div className="py-12 text-center text-slate-500 text-sm">
              {isTa
                ? 'இன்னும் மதிப்பெண்கள் பதிவாகவில்லை. விளையாடி சாதனையைப் பதியுங்கள்!'
                : isFr
                ? 'Aucun score enregistré pour l’instant. Joue une partie pour battre le record !'
                : isEs
                ? 'No hay puntuaciones registradas aún. ¡Juega para establecer un récord!'
                : isHi
                ? 'अभी कोई रिकॉर्ड दर्ज नहीं है। खेलकर नया रिकॉर्ड बनाएँ!'
                : 'No local scores recorded for this filter yet. Play a puzzle to set the record!'}
            </div>
          ) : (
            <table className="w-full text-left border-collapse">
              <thead>
                <tr className="text-[11px] font-mono text-slate-500 uppercase tracking-wider pb-2 border-b border-slate-800">
                  <th className="pb-3 pl-2 w-12 font-medium">{t('rank', currentLang)}</th>
                  <th className="pb-3 font-medium">{t('player', currentLang)}</th>
                  <th className="pb-3 font-medium">{isTa ? 'சவால்' : isFr ? 'Défi' : isEs ? 'Desafío' : isHi ? 'चुनौती' : 'Challenge'}</th>
                  <th className="pb-3 font-medium">{isTa ? 'சிரமம்' : isFr ? 'Difficulté' : isEs ? 'Dificultad' : isHi ? 'कठिनाई' : 'Difficulty'}</th>
                  <th className="pb-3 text-right font-medium">Est. IQ</th>
                  <th className="pb-3 text-right font-medium">{t('score', currentLang)}</th>
                  <th className="pb-3 text-right pr-2 font-medium">{t('time', currentLang)}</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/40 text-xs">
                {filteredEntries.map((item, idx) => {
                  const isCurrentRun = highlightId && item.id === highlightId;
                  const isTop3 = idx < 3;

                  let rankBadge = (
                    <span className="font-mono text-slate-500 font-medium">#{idx + 1}</span>
                  );
                  if (idx === 0) {
                    rankBadge = (
                      <span className="w-6 h-6 rounded-md bg-amber-500/20 text-amber-300 font-bold flex items-center justify-center font-mono text-xs">
                        1
                      </span>
                    );
                  } else if (idx === 1) {
                    rankBadge = (
                      <span className="w-6 h-6 rounded-md bg-slate-300/20 text-slate-200 font-bold flex items-center justify-center font-mono text-xs">
                        2
                      </span>
                    );
                  } else if (idx === 2) {
                    rankBadge = (
                      <span className="w-6 h-6 rounded-md bg-amber-700/20 text-amber-500 font-bold flex items-center justify-center font-mono text-xs">
                        3
                      </span>
                    );
                  }

                  return (
                    <tr
                      key={item.id}
                      className={`hover:bg-slate-800/40 transition-colors ${
                        isCurrentRun
                          ? 'bg-cyan-950/30 border-l-2 border-cyan-400'
                          : item.isUser
                          ? 'bg-slate-850/40'
                          : ''
                      }`}
                    >
                      <td className="py-3 pl-2">{rankBadge}</td>

                      <td className="py-3 font-medium text-slate-200">
                        <div className="flex items-center gap-2">
                          <span className="font-semibold text-slate-100">{item.playerName}</span>
                          {item.isUser && (
                            <span className="text-[10px] text-cyan-400 font-mono">YOU</span>
                          )}
                        </div>
                        {item.notes && (
                          <span className="text-[10px] text-slate-500 block truncate max-w-[200px]">
                            {item.notes}
                          </span>
                        )}
                      </td>

                      <td className="py-3 capitalize text-slate-400">
                        {item.mode === 'child'
                          ? '⭐ Child IQ (Easy)'
                          : item.mode === 'detective'
                          ? (currentLang === 'ta' ? '🕵️‍♂️ துப்பறியும் Arunan' : '🕵️‍♂️ Detective Arunan')
                          : item.mode === 'english'
                          ? (currentLang === 'ta' ? '🔤 சுலப ஆங்கிலம்' : '🔤 Easy English')
                          : item.mode === 'grid'
                          ? 'Grid Logic'
                          : item.mode === 'pattern'
                          ? 'Pattern Matrix'
                          : item.mode === 'sequence'
                          ? 'Sequences'
                          : 'IQ Assessment'}
                      </td>

                      <td className="py-3">
                        <span className="capitalize text-slate-300 font-mono text-[11px]">
                          {item.difficulty}
                        </span>
                      </td>

                      <td className="py-3 text-right">
                        <span className="font-mono font-bold text-cyan-400 tabular-nums">
                          {item.iqEstimate}
                        </span>
                      </td>

                      <td className="py-3 text-right font-mono font-bold text-slate-100 tabular-nums">
                        {item.score.toLocaleString()}
                      </td>

                      <td className="py-3 text-right pr-2 font-mono text-slate-400 tabular-nums">
                        {formatTime(item.timeSeconds)}
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          )}
        </div>

        {/* Footer */}
        <div className="px-6 py-3 border-t border-slate-800 bg-slate-950 flex items-center justify-between text-xs text-slate-500">
          <span>{filteredEntries.length} Records Persisted</span>
          <span>Saved to local browser storage</span>
        </div>
      </div>
    </div>
  );
};
