import React, { useState, useEffect } from 'react';
import { Difficulty, GameMode } from './types/game';
import { AppLanguage } from './types/i18n';
import { getInitialLanguage, saveLanguage, t } from './utils/i18n';
import { Header } from './components/Header';
import { ChildGame } from './components/ChildGame';
import { DetectiveMehulGame } from './components/DetectiveMehulGame';
import { EnglishLearningGame } from './components/EnglishLearningGame';
import { GridGame } from './components/GridGame';
import { PatternGame } from './components/PatternGame';
import { SequenceGame } from './components/SequenceGame';
import { IQAssessment } from './components/IQAssessment';
import { LeaderboardModal } from './components/LeaderboardModal';
import { ProfileModal } from './components/ProfileModal';
import { WinModal } from './components/WinModal';
import { AppIntroModal } from './components/AppIntroModal';
import { WebsitePortal } from './components/WebsitePortal';
import { InstallAppModal } from './components/InstallAppModal';
import { LanguageModal } from './components/LanguageModal';
import { SafetyModal } from './components/SafetyModal';
import { sound } from './utils/audio';
import { loadActiveMode, saveActiveMode } from './utils/gameSessionStorage';
import { Brain, Grid3X3, Shapes, Hash, Trophy, Sparkles, CheckCircle, ShieldCheck, Star, BookmarkCheck, Smartphone, Globe2 } from 'lucide-react';

export default function App() {
  const [currentMode, setCurrentMode] = useState<GameMode>(() => loadActiveMode());
  const [currentLang, setCurrentLang] = useState<AppLanguage>(getInitialLanguage());
  const [viewMode, setViewMode] = useState<'app' | 'website'>('app');
  const [isLeaderboardOpen, setIsLeaderboardOpen] = useState(false);
  const [isProfileOpen, setIsProfileOpen] = useState(false);
  const [isWinModalOpen, setIsWinModalOpen] = useState(false);
  const [isIntroOpen, setIsIntroOpen] = useState(false);
  const [isInstallOpen, setIsInstallOpen] = useState(false);
  const [isLanguageModalOpen, setIsLanguageModalOpen] = useState(false);
  const [isSafetyModalOpen, setIsSafetyModalOpen] = useState(false);
  const [deferredPrompt, setDeferredPrompt] = useState<any>(null);
  const [isMuted, setIsMuted] = useState(sound.getMuted());

  useEffect(() => {
    saveActiveMode(currentMode);
  }, [currentMode]);

  useEffect(() => {
    const handlePrompt = (e: Event) => {
      e.preventDefault();
      setDeferredPrompt(e);
    };
    window.addEventListener('beforeinstallprompt', handlePrompt);
    return () => window.removeEventListener('beforeinstallprompt', handlePrompt);
  }, []);

  const handleTriggerInstall = async () => {
    if (deferredPrompt) {
      try {
        deferredPrompt.prompt();
        const choice = await deferredPrompt.userChoice;
        if (choice?.outcome === 'accepted') {
          setDeferredPrompt(null);
          setIsInstallOpen(false);
        }
      } catch {
        // ignore
      }
    }
  };

  useEffect(() => {
    const handleVisibility = () => {
      if (document.visibilityState === 'hidden') {
        saveActiveMode(currentMode);
      }
    };
    document.addEventListener('visibilitychange', handleVisibility);
    window.addEventListener('beforeunload', handleVisibility);
    return () => {
      document.removeEventListener('visibilitychange', handleVisibility);
      window.removeEventListener('beforeunload', handleVisibility);
    };
  }, [currentMode]);

  useEffect(() => {
    try {
      const seen = localStorage.getItem('arunan_iq_intro_seen');
      if (!seen) {
        setIsIntroOpen(true);
      }
    } catch {
      // ignore
    }
  }, []);
  const [lastWinStats, setLastWinStats] = useState<{
    mode: GameMode;
    difficulty: Difficulty;
    score: number;
    iqEstimate: number;
    timeSeconds: number;
    accuracy: number;
    title: string;
  } | null>(null);

  const handleSelectLanguage = (lang: AppLanguage) => {
    setCurrentLang(lang);
    saveLanguage(lang);
  };

  const handleToggleMute = () => {
    const next = sound.toggleMute();
    setIsMuted(next);
  };

  const handleGameWin = (stats: {
    mode: GameMode;
    difficulty: Difficulty;
    score: number;
    iqEstimate: number;
    timeSeconds: number;
    accuracy: number;
    title: string;
  }) => {
    setLastWinStats(stats);
    setIsWinModalOpen(true);
  };

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col selection:bg-amber-500/30 selection:text-amber-200">
      {/* Top Bar Navigation */}
      <Header
        currentMode={currentMode}
        onSelectMode={(mode) => {
          setCurrentMode(mode);
          if (viewMode === 'website') setViewMode('app');
        }}
        onOpenLeaderboard={() => setIsLeaderboardOpen(true)}
        onOpenProfile={() => setIsProfileOpen(true)}
        onOpenIntro={() => setIsIntroOpen(true)}
        isMuted={isMuted}
        onToggleMute={handleToggleMute}
        currentLang={currentLang}
        onSelectLanguage={handleSelectLanguage}
        viewMode={viewMode}
        onToggleViewMode={setViewMode}
        onOpenInstall={() => setIsInstallOpen(true)}
        onOpenLanguageModal={() => setIsLanguageModalOpen(true)}
        onOpenSafetyModal={() => setIsSafetyModalOpen(true)}
      />

      {/* Main Content Area */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 py-8">
        {viewMode === 'website' ? (
          <WebsitePortal
            currentLang={currentLang}
            onLaunchMode={(mode) => {
              setCurrentMode(mode);
              setViewMode('app');
            }}
            onOpenInstall={() => setIsInstallOpen(true)}
            isInstallable={Boolean(deferredPrompt)}
            onSelectLanguage={handleSelectLanguage}
            onOpenSafetyModal={() => setIsSafetyModalOpen(true)}
          />
        ) : (
          <>
            {/* Mode Hero Banner / Context */}
            <div className="mb-8">
          <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-4 pb-4 border-b border-slate-800/80">
            <div>
              <div className="flex items-center gap-2 text-xs font-mono uppercase tracking-wider mb-1">
                {currentMode === 'child' && (
                  <>
                    <Star className="w-3.5 h-3.5 text-amber-400 fill-amber-400" />
                    <span className="text-amber-400 font-bold">
                      {currentLang === 'ta'
                        ? 'சுட்டி IQ எளிய அரங்கம் · ஆரம்பநிலை மூளைப் புதிர்'
                        : currentLang === 'fr'
                        ? 'Arène QI Enfant · Puzzles Débutants'
                        : currentLang === 'es'
                        ? 'Arena CI Infantil · Acertijos para Niños'
                        : currentLang === 'hi'
                        ? 'बाल IQ सरल एरीना · शुरुआती पहेलियाँ'
                        : 'Child IQ Easy Arena · Junior Mind Puzzles'}
                    </span>
                  </>
                )}
                {currentMode === 'detective' && (
                  <>
                    <span className="text-base leading-none">🕵️‍♂️</span>
                    <span className="text-red-400 font-bold">
                      {currentLang === 'ta'
                        ? 'துப்பறியும் Arunan · மர்மக் குற்றப் புதிர்கள்'
                        : currentLang === 'fr'
                        ? 'Détective Arunan · Énigmes Criminelles'
                        : currentLang === 'es'
                        ? 'Detective Arunan · Misterios y Deducción'
                        : currentLang === 'hi'
                        ? 'जासूस अरूनन · रहस्य और अपराध पहेलियाँ'
                        : 'Detective Arunan · Mystery Crime Riddles'}
                    </span>
                  </>
                )}
                {currentMode === 'english' && (
                  <>
                    <span className="text-base leading-none">🔤</span>
                    <span className="text-indigo-400 font-bold">
                      {currentLang === 'ta'
                        ? 'சுலப ஆங்கிலக் கல்வி · தமிழ் வழியில் சரியான இலக்கணம்'
                        : currentLang === 'fr'
                        ? 'Apprentissage d’Anglais Facile et Correct'
                        : currentLang === 'es'
                        ? 'Aprende Inglés Fácil y Correcto'
                        : currentLang === 'hi'
                        ? 'आसान और सही अंग्रेज़ी सीखें'
                        : 'Easy & Correct English Learning · Grammar & Daily Usage'}
                    </span>
                  </>
                )}
                {currentMode === 'grid' && (
                  <>
                    <Grid3X3 className="w-3.5 h-3.5 text-cyan-400" />
                    <span className="text-cyan-400">Deductive Binary Logic · Nonogram Matrix</span>
                  </>
                )}
                {currentMode === 'pattern' && (
                  <>
                    <Shapes className="w-3.5 h-3.5 text-cyan-400" />
                    <span className="text-cyan-400">Raven's Progressive Matrices · Abstract Geometry</span>
                  </>
                )}
                {currentMode === 'sequence' && (
                  <>
                    <Hash className="w-3.5 h-3.5 text-cyan-400" />
                    <span className="text-cyan-400">Cognitive Sequences · Mathematical Intuition</span>
                  </>
                )}
                {currentMode === 'assessment' && (
                  <>
                    <Brain className="w-3.5 h-3.5 text-emerald-400" />
                    <span className="text-emerald-400">Psychometric Battery · Standardized IQ Scale</span>
                  </>
                )}
              </div>

              <h1 className="text-2xl sm:text-3xl font-black text-white tracking-tight">
                {currentMode === 'child' &&
                  (currentLang === 'ta'
                    ? 'அருணன் IQ · சுட்டி IQ (எளிது)'
                    : currentLang === 'fr'
                    ? 'Arunan IQ · Enfant QI (Facile)'
                    : currentLang === 'es'
                    ? 'Arunan IQ · Niño CI (Fácil)'
                    : currentLang === 'hi'
                    ? 'अरुणन IQ · बाल IQ (सरल)'
                    : 'Arunan IQ · Child IQ (Easy)')}
                {currentMode === 'detective' &&
                  (currentLang === 'ta'
                    ? 'துப்பறியும் Arunan: தமிழ் மர்மக் கதைகள்'
                    : currentLang === 'fr'
                    ? 'Détective Arunan : Mystères et Énigmes'
                    : currentLang === 'es'
                    ? 'Detective Arunan : Enigmas de Misterio'
                    : currentLang === 'hi'
                    ? 'जासूस अरूनन : रहस्यमयी पहेलियाँ'
                    : 'Detective Arunan: Mystery Crime Riddles')}
                {currentMode === 'english' &&
                  (currentLang === 'ta'
                    ? 'சுலபமான மற்றும் சரியான ஆங்கிலக் கல்வி (Easy & Correct English)'
                    : currentLang === 'fr'
                    ? 'Apprentissage de l’Anglais Facile et Correct'
                    : currentLang === 'es'
                    ? 'Aprende Inglés Fácil y Correcto'
                    : currentLang === 'hi'
                    ? 'आसान और सही अंग्रेज़ी सीखें'
                    : 'Easy & Correct English Learning')}
                {currentMode === 'grid' && t('modeGrid', currentLang)}
                {currentMode === 'pattern' && t('modePattern', currentLang)}
                {currentMode === 'sequence' && t('modeSequence', currentLang)}
                {currentMode === 'assessment' && t('modeAssessment', currentLang)}
              </h1>

              <div className="flex flex-wrap items-center gap-2 text-xs text-slate-400 mt-1.5">
                <span>100% Offline</span>
                <span aria-hidden="true">·</span>
                <span>5 Languages (FR / TA / ES / HI / EN)</span>
                <span aria-hidden="true">·</span>
                <span className="text-emerald-400 font-semibold flex items-center gap-1">
                  <BookmarkCheck className="w-3.5 h-3.5 text-emerald-400" />
                  <span>
                    {currentLang === 'ta'
                      ? 'நிலைகள் தானாகத் தொடரும்'
                      : currentLang === 'fr'
                      ? 'Niveaux sauvegardés automatiquement'
                      : currentLang === 'es'
                      ? 'Niveles continuos automáticos'
                      : currentLang === 'hi'
                      ? 'लेवल अपने-आप जारी रहेंगे'
                      : 'Auto-Saved Level Continuity'}
                  </span>
                </span>
                <span aria-hidden="true">·</span>
                <span>{t('offlineNotice', currentLang)}</span>
              </div>
            </div>

            {/* Quick Status & Intro */}
            <div className="flex items-center gap-3 text-xs font-mono">
              <button
                type="button"
                onClick={() => {
                  sound.playClick(500);
                  setIsIntroOpen(true);
                }}
                className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-amber-500/15 hover:bg-amber-500/25 text-amber-300 border border-amber-500/35 transition-all cursor-pointer font-bold shadow-sm"
              >
                <Sparkles className="w-3.5 h-3.5 text-amber-400" />
                <span>
                  {currentLang === 'ta'
                    ? '✨ அறிமுகம்'
                    : currentLang === 'fr'
                    ? '✨ Intro'
                    : currentLang === 'es'
                    ? '✨ Intro'
                    : currentLang === 'hi'
                    ? '✨ ऐप परिचय'
                    : '✨ App Intro'}
                </span>
              </button>
              <div className="hidden md:flex items-center gap-2 text-slate-400">
                <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
                <span>Offline Ready · Arunan IQ</span>
              </div>
            </div>
          </div>
        </div>

        {/* Dynamic Game Arena */}
        <div className="transition-all duration-200">
          {currentMode === 'child' && (
            <ChildGame currentLang={currentLang} onWin={handleGameWin} />
          )}
          {currentMode === 'detective' && (
            <DetectiveMehulGame
              currentLang={currentLang}
              onSelectLanguage={handleSelectLanguage}
              onWin={handleGameWin}
            />
          )}
          {currentMode === 'english' && (
            <EnglishLearningGame currentLang={currentLang} onWin={handleGameWin} />
          )}
          {currentMode === 'grid' && (
            <GridGame currentLang={currentLang} onWin={handleGameWin} />
          )}
          {currentMode === 'pattern' && (
            <PatternGame currentLang={currentLang} onWin={handleGameWin} />
          )}
          {currentMode === 'sequence' && <SequenceGame onWin={handleGameWin} />}
          {currentMode === 'assessment' && (
            <IQAssessment
              onFinish={(res) => {
                setLastWinStats({
                  mode: 'assessment',
                  difficulty: 'master',
                  score: res.score,
                  iqEstimate: res.iq,
                  timeSeconds: res.timeSeconds,
                  accuracy: res.accuracy,
                  title: 'Comprehensive IQ Assessment',
                });
                setIsWinModalOpen(true);
              }}
            />
          )}
        </div>
          </>
        )}
      </main>

      {/* Footer */}
      <footer className="border-t border-slate-900 bg-slate-950 py-6 text-xs text-slate-500">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 flex flex-col sm:flex-row items-center justify-between gap-4">
          <div className="flex flex-wrap items-center gap-2">
            <span className="font-bold text-slate-200">ARUNAN IQ</span>
            <span aria-hidden="true">·</span>
            <span className="px-2.5 py-0.5 rounded-full bg-red-950/70 border border-red-500/40 text-red-300 font-semibold font-mono shadow-sm">
              Made by Arunan S
            </span>
            <span aria-hidden="true">·</span>
            <span>Multilingual IQ & Detective Arena (Français, தமிழ், Español, हिन्दी, English)</span>
            <span aria-hidden="true">·</span>
            <span className="text-emerald-400 font-medium">100% Offline App & Website</span>
          </div>
          <div className="flex items-center gap-3 sm:gap-4 flex-wrap">
            <button
              type="button"
              onClick={() => {
                sound.playClick(500);
                setViewMode(viewMode === 'app' ? 'website' : 'app');
              }}
              className="px-2.5 py-1 rounded-lg bg-amber-500/10 hover:bg-amber-500/20 text-amber-300 border border-amber-500/30 font-semibold transition-colors cursor-pointer"
            >
              {viewMode === 'app' ? '🌐 View Website' : '🎮 Play in App'}
            </button>
            <button
              type="button"
              onClick={() => {
                sound.playClick(500);
                setIsInstallOpen(true);
              }}
              className="px-2.5 py-1 rounded-lg bg-emerald-500/10 hover:bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 font-semibold transition-colors cursor-pointer"
            >
              📲 Install App
            </button>
            <button
              type="button"
              onClick={() => {
                sound.playClick(440);
                setIsSafetyModalOpen(true);
              }}
              className="px-2.5 py-1 rounded-lg bg-emerald-950/70 hover:bg-emerald-900/70 text-emerald-300 border border-emerald-500/40 font-semibold transition-colors cursor-pointer flex items-center gap-1.5"
              title="View Safety & Privacy Guarantee"
            >
              <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
              <span>{currentLang === 'ta' ? 'பாதுகாப்பான தளம்' : 'Safe Website'}</span>
            </button>
            <button
              type="button"
              onClick={() => setIsLeaderboardOpen(true)}
              className="hover:text-slate-300 transition-colors cursor-pointer"
            >
              {t('leaderboard', currentLang)}
            </button>
            <button
              type="button"
              onClick={() => setIsProfileOpen(true)}
              className="hover:text-slate-300 transition-colors cursor-pointer"
            >
              {t('stats', currentLang)}
            </button>
          </div>
        </div>
      </footer>

      {/* Modals */}
      <InstallAppModal
        isOpen={isInstallOpen}
        onClose={() => setIsInstallOpen(false)}
        currentLang={currentLang}
        deferredPrompt={deferredPrompt}
        onTriggerInstall={handleTriggerInstall}
      />

      <LeaderboardModal
        isOpen={isLeaderboardOpen}
        onClose={() => setIsLeaderboardOpen(false)}
        currentLang={currentLang}
      />

      <ProfileModal
        isOpen={isProfileOpen}
        onClose={() => setIsProfileOpen(false)}
      />

      <WinModal
        isOpen={isWinModalOpen}
        onClose={() => setIsWinModalOpen(false)}
        onPlayNext={() => setIsWinModalOpen(false)}
        onOpenLeaderboard={() => {
          setIsWinModalOpen(false);
          setIsLeaderboardOpen(true);
        }}
        stats={lastWinStats}
      />

      <AppIntroModal
        isOpen={isIntroOpen}
        onClose={() => setIsIntroOpen(false)}
        currentLang={currentLang}
        onSelectMode={(mode) => setCurrentMode(mode)}
        onSelectLanguage={handleSelectLanguage}
      />

      <LanguageModal
        isOpen={isLanguageModalOpen}
        onClose={() => setIsLanguageModalOpen(false)}
        currentLang={currentLang}
        onSelectLanguage={handleSelectLanguage}
      />

      <SafetyModal
        isOpen={isSafetyModalOpen}
        onClose={() => setIsSafetyModalOpen(false)}
        currentLang={currentLang}
      />
    </div>
  );
}
