import { Difficulty, GameMode, LeaderboardEntry, UserProfile } from '../types/game';

const LEADERBOARD_KEY = 'arunan_iq_leaderboard_v3';
const PROFILE_KEY = 'arunan_iq_user_profile_v3';

// Pre-seeded benchmark records to make the leaderboard vibrant & competitive
const DEFAULT_BENCHMARKS: LeaderboardEntry[] = [
  {
    id: 'seed-mehul-1',
    playerName: 'CID Inspector Kumar',
    mode: 'detective',
    difficulty: 'medium',
    score: 6400,
    iqEstimate: 138,
    timeSeconds: 38,
    accuracy: 100,
    date: '2026-03-30T04:30:00.000Z',
    notes: 'துப்பறியும் அருணன்: செட்டிநாடு மாளிகை வைரத் திருட்டு (Solved)',
  },
  {
    id: 'seed-kid-1',
    playerName: 'Little Leo (Age 8)',
    mode: 'child',
    difficulty: 'easy',
    score: 4200,
    iqEstimate: 128,
    timeSeconds: 22,
    accuracy: 100,
    date: '2026-03-30T04:10:00.000Z',
    notes: 'Child IQ: Twinkle Bright Star (⭐⭐⭐)',
  },
  {
    id: 'seed-kid-2',
    playerName: 'Maya Star (Age 7)',
    mode: 'child',
    difficulty: 'easy',
    score: 3850,
    iqEstimate: 122,
    timeSeconds: 28,
    accuracy: 100,
    date: '2026-03-30T03:45:00.000Z',
    notes: 'Child IQ: Puppy & Kitty March (⭐⭐⭐)',
  },
  {
    id: 'seed-1',
    playerName: 'Ada Lovelace',
    mode: 'assessment',
    difficulty: 'master',
    score: 9850,
    iqEstimate: 148,
    timeSeconds: 215,
    accuracy: 98,
    date: '2026-03-24T14:30:00.000Z',
    notes: 'Mensa Grandmaster Benchmark',
  },
  {
    id: 'seed-2',
    playerName: 'Alan Turing',
    mode: 'grid',
    difficulty: 'master',
    score: 8900,
    iqEstimate: 144,
    timeSeconds: 98,
    accuracy: 100,
    date: '2026-03-25T11:15:00.000Z',
    notes: 'Flawless 8x8 Deductive Run',
  },
  {
    id: 'seed-3',
    playerName: 'Carl Friedrich',
    mode: 'pattern',
    difficulty: 'hard',
    score: 7850,
    iqEstimate: 139,
    timeSeconds: 64,
    accuracy: 96,
    date: '2026-03-26T09:20:00.000Z',
    notes: 'Raven Matrix Specialist',
  },
  {
    id: 'seed-4',
    playerName: 'Hypatia',
    mode: 'sequence',
    difficulty: 'hard',
    score: 7200,
    iqEstimate: 135,
    timeSeconds: 52,
    accuracy: 94,
    date: '2026-03-27T16:45:00.000Z',
    notes: 'Geometric Sequences',
  },
  {
    id: 'seed-5',
    playerName: 'Claude Shannon',
    mode: 'grid',
    difficulty: 'medium',
    score: 5900,
    iqEstimate: 128,
    timeSeconds: 74,
    accuracy: 92,
    date: '2026-03-28T19:00:00.000Z',
    notes: 'Binary Logic Speedrun',
  },
  {
    id: 'seed-6',
    playerName: 'Emmy Noether',
    mode: 'assessment',
    difficulty: 'hard',
    score: 8400,
    iqEstimate: 141,
    timeSeconds: 280,
    accuracy: 95,
    date: '2026-03-29T10:10:00.000Z',
    notes: 'Cognitive Synthesis',
  },
  {
    id: 'seed-7',
    playerName: 'Archimedes',
    mode: 'pattern',
    difficulty: 'medium',
    score: 5100,
    iqEstimate: 125,
    timeSeconds: 88,
    accuracy: 90,
    date: '2026-03-29T21:30:00.000Z',
    notes: 'Spatial Rotation Master',
  },
  {
    id: 'seed-8',
    playerName: 'Ada V.',
    mode: 'grid',
    difficulty: 'easy',
    score: 3400,
    iqEstimate: 115,
    timeSeconds: 42,
    accuracy: 100,
    date: '2026-03-30T02:00:00.000Z',
    notes: 'Clean 5x5 Sprint',
  },
];

const DEFAULT_PROFILE: UserProfile = {
  playerName: 'Player 1',
  gamesPlayed: 0,
  gamesWon: 0,
  highestIQ: 100,
  bestScores: {},
  unlockedBadges: [],
  soundEnabled: true,
};

export function getLeaderboard(): LeaderboardEntry[] {
  try {
    const raw = localStorage.getItem(LEADERBOARD_KEY);
    if (!raw) {
      localStorage.setItem(LEADERBOARD_KEY, JSON.stringify(DEFAULT_BENCHMARKS));
      return DEFAULT_BENCHMARKS;
    }
    const parsed: LeaderboardEntry[] = JSON.parse(raw);
    return parsed.sort((a, b) => b.score - a.score);
  } catch (err) {
    console.error('Failed reading leaderboard from localStorage', err);
    return DEFAULT_BENCHMARKS;
  }
}

export function saveScoreToLeaderboard(
  entry: Omit<LeaderboardEntry, 'id' | 'date'>
): LeaderboardEntry {
  const all = getLeaderboard();
  const newEntry: LeaderboardEntry = {
    ...entry,
    id: 'user-' + Date.now() + '-' + Math.random().toString(36).substring(2, 7),
    date: new Date().toISOString(),
    isUser: true,
  };

  all.push(newEntry);
  all.sort((a, b) => b.score - a.score);

  // Keep top 100 entries to prevent infinite bloat
  const trimmed = all.slice(0, 100);

  try {
    localStorage.setItem(LEADERBOARD_KEY, JSON.stringify(trimmed));
  } catch (e) {
    console.error('Failed saving score to localStorage', e);
  }

  // Also update user profile stats
  updateStatsOnGameEnd(newEntry);

  return newEntry;
}

export function clearLeaderboard(): void {
  try {
    localStorage.setItem(LEADERBOARD_KEY, JSON.stringify(DEFAULT_BENCHMARKS));
  } catch (e) {
    console.error('Failed clearing leaderboard', e);
  }
}

export function exportLeaderboardJson(): string {
  const data = {
    leaderboard: getLeaderboard(),
    profile: getUserProfile(),
    exportedAt: new Date().toISOString(),
  };
  return JSON.stringify(data, null, 2);
}

export function importLeaderboardJson(jsonString: string): boolean {
  try {
    const data = JSON.parse(jsonString);
    if (Array.isArray(data.leaderboard)) {
      localStorage.setItem(LEADERBOARD_KEY, JSON.stringify(data.leaderboard));
    }
    if (data.profile && typeof data.profile.playerName === 'string') {
      localStorage.setItem(PROFILE_KEY, JSON.stringify(data.profile));
    }
    return true;
  } catch {
    return false;
  }
}

export function getUserProfile(): UserProfile {
  try {
    const raw = localStorage.getItem(PROFILE_KEY);
    if (!raw) {
      localStorage.setItem(PROFILE_KEY, JSON.stringify(DEFAULT_PROFILE));
      return DEFAULT_PROFILE;
    }
    return { ...DEFAULT_PROFILE, ...JSON.parse(raw) };
  } catch {
    return DEFAULT_PROFILE;
  }
}

export function updateUserProfile(partial: Partial<UserProfile>): UserProfile {
  const current = getUserProfile();
  const updated = { ...current, ...partial };
  try {
    localStorage.setItem(PROFILE_KEY, JSON.stringify(updated));
  } catch (e) {
    console.error('Failed updating profile', e);
  }
  return updated;
}

function updateStatsOnGameEnd(entry: LeaderboardEntry) {
  const profile = getUserProfile();
  const key = `${entry.mode}_${entry.difficulty}`;
  const currentBest = profile.bestScores[key] || 0;

  const newBestScores = {
    ...profile.bestScores,
    [key]: Math.max(currentBest, entry.score),
  };

  const newHighestIQ = Math.max(profile.highestIQ, entry.iqEstimate);

  // Check achievements/badges
  const badges = new Set(profile.unlockedBadges);
  badges.add('First Move'); // completed a game
  if (entry.accuracy === 100) badges.add('Flawless Deductor');
  if (entry.score >= 5000) badges.add('High Scorer (5k+)');
  if (entry.score >= 8000) badges.add('Master Strategist (8k+)');
  if (entry.iqEstimate >= 130) badges.add('Gifted Mind (IQ 130+)');
  if (entry.iqEstimate >= 145) badges.add('Genius Tier (IQ 145+)');
  if (entry.timeSeconds <= 45 && entry.accuracy >= 90) badges.add('Speed Demon');
  if (entry.mode === 'assessment') badges.add('Certified Evaluated');

  updateUserProfile({
    gamesPlayed: profile.gamesPlayed + 1,
    gamesWon: profile.gamesWon + 1,
    highestIQ: newHighestIQ,
    bestScores: newBestScores,
    unlockedBadges: Array.from(badges),
  });
}

// Formula for calculating IQ based on score, mode, difficulty, time, errors
export function calculateIQEstimate(
  difficulty: Difficulty,
  timeSeconds: number,
  accuracy: number,
  mode: GameMode
): { iq: number; score: number } {
  const diffMultiplier = {
    easy: 1.0,
    medium: 1.25,
    hard: 1.55,
    master: 1.9,
  }[difficulty];

  // Base score
  const basePoints = {
    easy: 2000,
    medium: 3500,
    hard: 5500,
    master: 8000,
  }[difficulty];

  // Time bonus (faster gives more up to a limit)
  const targetTime = {
    easy: 60,
    medium: 120,
    hard: 200,
    master: 300,
  }[difficulty];

  const timeFactor = Math.max(0.4, Math.min(1.8, (targetTime * 1.5 - timeSeconds) / targetTime));
  const accuracyFactor = accuracy / 100;

  const rawScore = Math.round(basePoints * timeFactor * Math.pow(accuracyFactor, 1.8));

  // IQ Calculation: Standardized normal distribution around 100 (SD 15)
  // Base IQ for solving level at all:
  const baseIQ = {
    easy: 102,
    medium: 112,
    hard: 122,
    master: 132,
  }[difficulty];

  const speedBonusIQ = Math.round(Math.max(-8, Math.min(14, (targetTime - timeSeconds) / 10)));
  const accuracyBonusIQ = Math.round((accuracyFactor - 0.7) * 20);

  const rawIQ = Math.max(90, Math.min(160, baseIQ + speedBonusIQ + accuracyBonusIQ));

  return {
    iq: rawIQ,
    score: rawScore,
  };
}
