import sharp from 'sharp';
import fs from 'fs';
import path from 'path';

const publicDir = path.resolve('public');
if (!fs.existsSync(publicDir)) {
  fs.mkdirSync(publicDir, { recursive: true });
}

// SVG with safe zone padding for maskable icon
const maskableSvg = `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512" width="512" height="512">
  <rect width="512" height="512" fill="#c41622" />
  <!-- Scaled content centered within safe zone (80% scale = 10% padding on each side) -->
  <g transform="translate(51.2, 51.2) scale(0.8)">
    <g transform="translate(54, 214)">
      <!-- Brain Icon -->
      <g transform="translate(0, 16) scale(1.15)">
        <path fill="none" stroke="#ffffff" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round" d="M22,38 C20,38 18,36 17,34 C13,34 10,31 10,27 C7,26 5,23 5,19 C5,15 8,11 11,10 C11,6 14,3 18,3 C21,3 23,4 24,6 C25,4 28,3 30,3 C30,7 29,11 28,14 C29,18 28,23 26,26 C28,29 27,33 25,35 C24,37 23,38 22,38 Z" />
        <path fill="none" stroke="#ffffff" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round" d="M11,10 C14,12 17,11 18,14 C19,17 16,19 14,19" />
        <path fill="none" stroke="#ffffff" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round" d="M10,27 C13,26 15,28 17,27 C19,25 18,22 21,21" />
        <path fill="none" stroke="#ffffff" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round" d="M17,34 C19,32 20,30 22,31" />
        <path fill="none" stroke="#ffffff" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round" d="M18,3 C19,7 22,8 24,9" />
        <path fill="none" stroke="#ffffff" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round" d="M38,38 C40,38 42,36 43,34 C47,34 50,31 50,27 C53,26 55,23 55,19 C55,15 52,11 49,10 C49,6 46,3 42,3 C39,3 37,4 36,6 C35,4 32,3 30,3 C30,7 31,11 32,14 C31,18 32,23 34,26 C32,29 33,33 35,35 C36,37 37,38 38,38 Z" />
        <path fill="none" stroke="#ffffff" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round" d="M49,10 C46,12 43,11 42,14 C41,17 44,19 46,19" />
        <path fill="none" stroke="#ffffff" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round" d="M50,27 C47,26 45,28 43,27 C41,25 42,22 39,21" />
        <path fill="none" stroke="#ffffff" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round" d="M43,34 C41,32 40,30 38,31" />
        <path fill="none" stroke="#ffffff" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round" d="M42,3 C41,7 38,8 36,9" />
        <path fill="none" stroke="#ffffff" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round" d="M30,3 L30,37" stroke-dasharray="1.5,1.5" />
      </g>
      <!-- White Medallion with red AI -->
      <g transform="translate(104, 36)">
        <circle cx="0" cy="0" r="36" fill="#ffffff" />
        <text x="0" y="11" text-anchor="middle" font-family="'Times New Roman', serif" font-weight="bold" font-size="34" fill="#c41622">AI</text>
      </g>
      <!-- ARUNAN IQ Text -->
      <text x="150" y="47" font-family="system-ui, sans-serif" font-weight="300" font-size="34" letter-spacing="4px" fill="#ffffff">ARUNAN IQ</text>
    </g>
  </g>
</svg>`;

async function generate() {
  const logoSvg = fs.readFileSync(path.join(publicDir, 'logo.svg'));

  console.log('Generating PWA icons...');
  // 512x512
  await sharp(logoSvg)
    .resize(512, 512)
    .png()
    .toFile(path.join(publicDir, 'pwa-512x512.png'));

  // 192x192
  await sharp(logoSvg)
    .resize(192, 192)
    .png()
    .toFile(path.join(publicDir, 'pwa-192x192.png'));

  // 180x180 for iOS apple-touch-icon
  await sharp(logoSvg)
    .resize(180, 180)
    .png()
    .toFile(path.join(publicDir, 'apple-touch-icon.png'));

  // 64x64 favicon
  await sharp(logoSvg)
    .resize(64, 64)
    .png()
    .toFile(path.join(publicDir, 'favicon.png'));

  // 512x512 maskable icon with safe zone
  await sharp(Buffer.from(maskableSvg))
    .resize(512, 512)
    .png()
    .toFile(path.join(publicDir, 'pwa-maskable-512x512.png'));

  console.log('Successfully generated all PWA icons!');
}

generate().catch(err => {
  console.error('Failed generating icons:', err);
  process.exit(1);
});
